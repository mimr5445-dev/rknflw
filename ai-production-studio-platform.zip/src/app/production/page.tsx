import { db } from "@/db";
import { episodes, scenes } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { ProductionClient } from "@/components/production-client";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const metadata = { title: "خط الإنتاج — استوديو الهوية الثابتة" };

export default async function ProductionPage() {
  await ensureSeeded();
  const eps = await db.select().from(episodes).orderBy(desc(episodes.createdAt));
  const counts = await db
    .select({
      episodeId: scenes.episodeId,
      total: sql<number>`count(*)::int`,
      approved: sql<number>`count(*) filter (where ${scenes.status} = 'approved')::int`,
      generated: sql<number>`count(*) filter (where ${scenes.status} in ('generated','approved'))::int`,
    })
    .from(scenes)
    .groupBy(scenes.episodeId);

  const map = new Map(counts.map((c) => [c.episodeId, c]));
  const data = eps.map((e) => ({
    ...e,
    sceneCount: map.get(e.id)?.total ?? 0,
    approvedCount: map.get(e.id)?.approved ?? 0,
    generatedCount: map.get(e.id)?.generated ?? 0,
  }));

  return <ProductionClient initialEpisodes={data} />;
}
