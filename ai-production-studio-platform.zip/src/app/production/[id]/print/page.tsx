import { notFound } from "next/navigation";
import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { PrintBar } from "@/components/print-bar";
import { assemblePrompt, displayName, pad2 } from "@/lib/studio";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const metadata = { title: "ملف الحلقة PDF — استوديو الهوية الثابتة" };

export default async function PrintPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const [ep] = await db.select().from(episodes).where(eq(episodes.id, id));
  if (!ep) notFound();

  const sceneRows = await db.select().from(scenes).where(eq(scenes.episodeId, id)).orderBy(scenes.num);
  const allAssets = await db.select().from(assets).orderBy(assets.type, assets.sortOrder);
  const byId = new Map(allAssets.map((a) => [a.id, a]));

  type M = { kind: string; label: string };
  const missingAll: M[] = [];
  for (const s of sceneRows) {
    for (const m of (s.missing as M[]) || []) {
      if (!missingAll.some((x) => x.kind === m.kind && x.label === m.label)) missingAll.push(m);
    }
  }

  const usedIds = new Set<string>();
  for (const s of sceneRows) {
    ((s.characterIds as string[]) || []).forEach((c) => usedIds.add(c));
    ((s.propIds as string[]) || []).forEach((c) => usedIds.add(c));
    if (s.mapId) usedIds.add(s.mapId);
    if (s.bgId) usedIds.add(s.bgId);
  }
  const usedAssets = allAssets.filter((a) => usedIds.has(a.id) || a.type === "RULE" || a.type === "STYLE" || a.type === "MAP-STYLE");

  return (
    <div id="print-root" className="print-doc -mx-4 min-h-screen px-4 py-6 sm:-mx-6 sm:px-6 lg:-mx-10 lg:px-10">
      <PrintBar backHref={`/production/${ep.id}`} />

      <div className="print-paper mx-auto max-w-4xl p-8 sm:p-12">
        {/* الغلاف */}
        <header className="border-b-4 pb-8" style={{ borderColor: "#E9B44C" }}>
          <p className="font-mono-en text-[11px] tracking-[0.4em] text-zinc-500">FIXED IDENTITY STUDIO — PRODUCTION FILE</p>
          <h1 className="display mt-3 text-4xl text-zinc-900">
            {ep.code} — {ep.title}
          </h1>
          <p className="mt-3 text-sm leading-7 text-zinc-600">
            ملف إنتاج رسمي: السرد، المشاهد، البرومبتات، ومصادر الهوية المستخدمة. كل ما في هذا الملف ملزم — لا وجه ولا حدود من الخيال.
          </p>
          <div className="mt-4 flex flex-wrap gap-2 text-[11px] font-bold text-zinc-600">
            <span>الحالة: {ep.status}</span> · <span>{sceneRows.length} مشهد</span> · <span>{usedAssets.length} مصدر مستخدم</span>
          </div>
        </header>

        {/* السرد */}
        <section className="mt-8">
          <h2 className="display mb-3 text-xl text-zinc-900">السرد الخام</h2>
          <p className="whitespace-pre-wrap rounded-xl bg-zinc-100 p-5 text-sm leading-8 text-zinc-800">{ep.narrative || "—"}</p>
          {ep.notes && (
            <p className="mt-3 rounded-xl border border-amber-300 bg-amber-50 p-4 text-[13px] leading-7 text-amber-900">
              <b>ملاحظات إخراجية:</b> {ep.notes}
            </p>
          )}
        </section>

        {/* المصادر المستخدمة */}
        <section className="mt-8 page-break">
          <h2 className="display mb-3 text-xl text-zinc-900">سجل المصادر المستخدمة</h2>
          <table className="w-full border-collapse text-[12px]">
            <thead>
              <tr className="bg-zinc-900 text-white">
                <th className="p-2 text-start">المصدر الرسمي</th>
                <th className="p-2 text-start">النوع</th>
                <th className="p-2 text-start">تعليمات الاستخدام</th>
              </tr>
            </thead>
            <tbody>
              {usedAssets.map((a, i) => (
                <tr key={a.id} className={i % 2 ? "bg-zinc-50" : ""}>
                  <td className="border border-zinc-200 p-2 font-bold" dir="ltr">
                    {displayName(a)}
                  </td>
                  <td className="border border-zinc-200 p-2" dir="ltr">
                    {a.type}
                  </td>
                  <td className="border border-zinc-200 p-2 leading-6 text-zinc-700">{a.prompt || a.description || "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
          {usedAssets.some((a) => a.imagePath) && (
            <div className="mt-4 grid grid-cols-3 gap-3">
              {usedAssets
                .filter((a) => a.imagePath)
                .map((a) => (
                  <figure key={a.id} className="rounded-xl border border-zinc-200 p-2 text-center">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={a.imagePath!} alt={a.name} className="mx-auto h-32 rounded-lg object-contain" />
                    <figcaption className="mt-1 font-mono-en text-[9px] text-zinc-600" dir="ltr">
                      {displayName(a)}
                    </figcaption>
                  </figure>
                ))}
            </div>
          )}
        </section>

        {/* المشاهد */}
        {sceneRows.map((s, i) => {
          const actors = [
            ...((s.characterIds as string[]) || []).map((c) => byId.get(c)),
            s.mapId ? byId.get(s.mapId) : undefined,
            s.bgId ? byId.get(s.bgId) : undefined,
            ...((s.propIds as string[]) || []).map((c) => byId.get(c)),
          ]
            .filter(Boolean)
            .map((a) => displayName(a as (typeof allAssets)[number]))
            .join(" ، ");
          return (
            <section key={s.id} className={`mt-10 ${i > 0 ? "page-break" : ""}`}>
              <div className="flex items-center gap-4 border-b-2 border-zinc-900 pb-3">
                <span className="font-mono-en text-3xl font-extrabold text-zinc-900" dir="ltr">
                  {pad2(s.num)}
                </span>
                <div>
                  <h3 className="display text-lg text-zinc-900">{s.title}</h3>
                  <p className="text-[11px] text-zinc-500">
                    التعبير: {s.expression} · الكادر: {s.camera} · الإضاءة: {s.lighting} · الحالة: {s.status}
                  </p>
                </div>
              </div>
              <p className="mt-4 text-sm leading-8 text-zinc-800">
                <b>السرد:</b> {s.narration}
              </p>
              <p className="mt-2 text-[12px] leading-7 text-zinc-700">
                <b>الممثلون من المصادر:</b> {actors || "لا أحد"}
              </p>
              {s.imagePath && (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={s.imagePath} alt={s.title} className="mt-4 max-h-64 w-full rounded-xl border border-zinc-200 object-contain" />
              )}
              <pre className="mt-4 overflow-x-auto rounded-xl bg-zinc-900 p-4 text-left font-mono-en text-[11px] leading-6 text-emerald-200" dir="ltr">
                {assemblePrompt(s)}
              </pre>
              {(s.missing as M[])?.length > 0 && (
                <p className="mt-2 rounded-lg bg-red-50 p-3 text-[12px] font-bold text-red-700">
                  نواقص المشهد: {(s.missing as M[]).map((m) => `${m.kind} ← ${m.label}`).join(" ، ")}
                </p>
              )}
            </section>
          );
        })}

        {/* الختام */}
        <section className="mt-10 page-break">
          <h2 className="display mb-3 text-xl text-zinc-900">نواقص مطلوبة قبل التوليد</h2>
          {missingAll.length ? (
            <ul className="list-inside list-disc space-y-1 text-sm text-zinc-800">
              {missingAll.map((m) => (
                <li key={`${m.kind}-${m.label}`}>
                  أنشئ مرجع <b dir="ltr">{m.kind}</b> لـ «{m.label}»
                </li>
              ))}
            </ul>
          ) : (
            <p className="rounded-xl bg-emerald-50 p-4 text-sm text-emerald-800">الحقيبة مكتملة لهذه الحلقة.</p>
          )}
          <h2 className="display mb-3 mt-8 text-xl text-zinc-900">تأكيد الاستمرارية</h2>
          <p className="rounded-xl bg-zinc-100 p-4 text-sm leading-8 text-zinc-700">
            كل شخصية في هذه الحلقة مستدعاة من مصدر CHAR الخاص بها بنفس الهوية، والخريطة والنمط لم يتغيرا في أي مشهد.
            اختبار المتابع: أخفِ أسماء الشخصيات — من يعرفها من شكلها فقط فالهوية نجحت.
          </p>
          <p className="mt-10 border-t border-zinc-200 pt-4 text-center font-mono-en text-[10px] tracking-widest text-zinc-400">
            FIXED IDENTITY STUDIO — {ep.code} — END OF FILE
          </p>
        </section>
      </div>
    </div>
  );
}
