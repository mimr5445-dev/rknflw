import { notFound } from "next/navigation";
import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { EpisodeClient } from "@/components/episode-client";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export default async function EpisodePage({ params }: { params: Promise<{ id: string }> }) {
  await ensureSeeded();
  const { id } = await params;
  const [ep] = await db.select().from(episodes).where(eq(episodes.id, id));
  if (!ep) notFound();

  const sceneRows = await db.select().from(scenes).where(eq(scenes.episodeId, id)).orderBy(scenes.num);
  const allAssets = await db.select().from(assets).orderBy(assets.sortOrder);
  const styleLock = allAssets.find((a) => a.type === "STYLE" && a.styleLock)?.styleLock ?? "";

  type M = { kind: string; label: string };
  const missingAll: M[] = [];
  for (const s of sceneRows) {
    for (const m of (s.missing as M[]) || []) {
      if (!missingAll.some((x) => x.kind === m.kind && x.label === m.label)) missingAll.push(m);
    }
  }

  const gatesAuto = {
    chars: sceneRows.length > 0 && !missingAll.some((m) => m.kind === "CHAR"),
    ref: sceneRows.length > 0 && sceneRows.every((s) => s.promptRef.trim().length > 3),
    styleLock: sceneRows.length > 0 && sceneRows.every((s) => !!s.promptStyle && (!styleLock || s.promptStyle === styleLock)),
    maps: sceneRows.length > 0 && !sceneRows.some((s) => s.isMap && !s.mapId),
  };

  return (
    <EpisodeClient
      initialEpisode={ep}
      initialScenes={sceneRows}
      assets={allAssets}
      styleLock={styleLock}
      gatesAuto={gatesAuto}
      missingAll={missingAll}
    />
  );
}
