import { db } from "@/db";
import { assets } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

const EDITABLE = [
  "type",
  "name",
  "role",
  "nameEn",
  "description",
  "prompt",
  "styleLock",
  "era",
  "imagePath",
  "favorite",
  "sortOrder",
] as const;

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "جسم غير صالح" }, { status: 400 });

  const patch: Record<string, unknown> = { updatedAt: new Date() };
  for (const k of EDITABLE) {
    if (k in body) patch[k] = body[k];
  }
  const [row] = await db.update(assets).set(patch).where(eq(assets.id, id)).returning();
  if (!row) return Response.json({ error: "غير موجود" }, { status: 404 });
  return Response.json(row);
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const [row] = await db.delete(assets).where(eq(assets.id, id)).returning({ id: assets.id });
  if (!row) return Response.json({ error: "غير موجود" }, { status: 404 });
  return Response.json({ ok: true });
}
