import { db } from "@/db";
import { assets } from "@/db/schema";
import { SOURCE_TYPES } from "@/lib/studio";
import { and, desc, eq, ilike, or } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  const type = req.nextUrl.searchParams.get("type");
  const fav = req.nextUrl.searchParams.get("fav");
  const q = req.nextUrl.searchParams.get("q");

  const conds = [];
  if (type && type !== "ALL") conds.push(eq(assets.type, type));
  if (fav === "1") conds.push(eq(assets.favorite, true));
  if (q) {
    conds.push(
      or(ilike(assets.name, `%${q}%`), ilike(assets.description, `%${q}%`), ilike(assets.role, `%${q}%`))!
    );
  }

  const rows = await db
    .select()
    .from(assets)
    .where(conds.length ? and(...conds) : undefined)
    .orderBy(assets.sortOrder, desc(assets.createdAt));

  return Response.json(rows);
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body || typeof body.name !== "string" || !body.name.trim()) {
    return Response.json({ error: "الاسم مطلوب" }, { status: 400 });
  }
  if (!SOURCE_TYPES.some((t) => t.key === body.type)) {
    return Response.json({ error: "نوع المصدر غير صالح" }, { status: 400 });
  }
  const [row] = await db
    .insert(assets)
    .values({
      type: body.type,
      name: String(body.name).trim(),
      role: body.role ?? null,
      nameEn: body.nameEn ?? null,
      description: body.description ?? null,
      prompt: body.prompt ?? null,
      styleLock: body.styleLock ?? null,
      era: body.era ?? null,
      imagePath: body.imagePath ?? null,
      favorite: !!body.favorite,
      sortOrder: Number.isFinite(body.sortOrder) ? body.sortOrder : 0,
    })
    .returning();
  return Response.json(row, { status: 201 });
}
