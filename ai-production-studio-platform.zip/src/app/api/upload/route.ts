import { randomUUID } from "crypto";
import { mkdir, writeFile } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

const MIME_EXT: Record<string, string> = {
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "image/webp": ".webp",
  "image/gif": ".gif",
  "image/svg+xml": ".svg",
};

/** رفع الصور المرجعية والشرائح المولّدة → public/uploads */
export async function POST(req: Request) {
  try {
    const fd = await req.formData();
    const file = fd.get("file");
    if (!(file instanceof File)) {
      return Response.json({ error: "لم يتم إرفاق ملف" }, { status: 400 });
    }
    if (!MIME_EXT[file.type]) {
      return Response.json({ error: "يُسمح بالصور فقط (PNG/JPG/WebP/GIF/SVG)" }, { status: 415 });
    }
    if (file.size > 10 * 1024 * 1024) {
      return Response.json({ error: "الحد الأقصى 10MB" }, { status: 413 });
    }
    const dir = path.join(process.cwd(), "public", "uploads");
    await mkdir(dir, { recursive: true });
    const name = `${randomUUID()}${MIME_EXT[file.type]}`;
    await writeFile(path.join(dir, name), Buffer.from(await file.arrayBuffer()));
    return Response.json({ path: `/uploads/${name}` }, { status: 201 });
  } catch (e) {
    console.error(e);
    return Response.json({ error: "فشل الرفع" }, { status: 500 });
  }
}
