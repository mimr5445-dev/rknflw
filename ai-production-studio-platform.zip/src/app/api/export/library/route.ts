import { db } from "@/db";
import { assets } from "@/db/schema";
import { buildIdentityMarkdown } from "@/lib/export";
import { displayName, slug } from "@/lib/studio";
import { readFile } from "fs/promises";
import JSZip from "jszip";
import { NextRequest } from "next/server";
import path from "path";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

async function readPublic(relPath: string | null): Promise<Buffer | null> {
  if (!relPath || relPath.includes("..")) return null;
  try {
    return await readFile(path.join(process.cwd(), "public", relPath));
  } catch {
    return null;
  }
}

/** حزمة الهوية المقدسة — كل المصادر وصورها وتعليماتها (?format=zip|md) */
export async function GET(req: NextRequest) {
  const format = req.nextUrl.searchParams.get("format") || "zip";
  const all = await db.select().from(assets).orderBy(assets.type, assets.sortOrder);
  const md = buildIdentityMarkdown(all);

  if (format === "md") {
    return new Response(md, {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent("IDENTITY-PACKAGE")}.md`,
      },
    });
  }

  const zip = new JSZip();
  zip.file(
    "README.txt",
    [
      "حزمة الهوية المقدسة — استوديو الهوية الثابتة",
      "═══════════════════════════════════════════",
      "هذا الملف هو الحقيبة الكاملة للمصادر: وجوه الممثلين، أطلس الخرائط،",
      "أنماط الفن، مواقع التصوير، والعناصر المتكررة — ومع كل صورة ملف تعليماتها.",
      "ارفع IDENTITY-PACKAGE.md مع الصور لأي نموذج ذكاء ليبني مشاهد مطابقة للهوية.",
    ].join("\n")
  );
  zip.file("IDENTITY-PACKAGE.md", md);

  const manifest: Record<string, unknown>[] = [];
  for (const a of all) {
    const dir = `SOURCES/${a.type}__${slug(a.nameEn || a.name, a.id.slice(0, 8))}`;
    const img = await readPublic(a.imagePath);
    if (img) {
      const ext = a.imagePath!.split(".").pop() || "png";
      zip.file(`${dir}/reference.${ext}`, img);
    }
    zip.file(
      `${dir}/INSTRUCTIONS.txt`,
      [
        `بطاقة المصدر: ${displayName(a)}`,
        a.styleLock ? `STYLE LOCK: ${a.styleLock}` : null,
        "",
        a.description || "",
        "",
        `التعليمات: ${a.prompt || "—"}`,
      ]
        .filter((l) => l !== null)
        .join("\n")
    );
    manifest.push({ id: a.id, source: displayName(a), type: a.type, hasImage: !!img });
  }
  zip.file("MANIFEST.json", JSON.stringify({ count: all.length, sources: manifest }, null, 2));

  const buf = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent("IDENTITY-PACKAGE")}.zip`,
    },
  });
}
