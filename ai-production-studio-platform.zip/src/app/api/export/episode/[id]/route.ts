import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { buildEpisodeMarkdown, buildIdentityMarkdown, type MissingRef } from "@/lib/export";
import { assemblePrompt, displayName, pad2, slug } from "@/lib/studio";
import { eq } from "drizzle-orm";
import { readFile } from "fs/promises";
import JSZip from "jszip";
import { NextRequest } from "next/server";
import path from "path";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

type Ctx = { params: Promise<{ id: string }> };

async function readPublic(relPath: string | null): Promise<Buffer | null> {
  if (!relPath || relPath.includes("..")) return null;
  try {
    return await readFile(path.join(process.cwd(), "public", relPath));
  } catch {
    return null;
  }
}

function assetInstructions(a: (typeof assets.$inferSelect)): string {
  return [
    `بطاقة المصدر: ${displayName(a)}`,
    `النوع: ${a.type}`,
    a.role ? `الوظيفة: ${a.role}` : null,
    a.era ? `الفترة: ${a.era}` : null,
    a.nameEn ? `الاسم الإنجليزي: ${a.nameEn}` : null,
    "",
    "وصف الهوية:",
    a.description || "—",
    "",
    "تعليمات الاستخدام مع هذه الصورة:",
    a.prompt || "أرفق هذه الصورة نفسها مع كل مشهد يذكرها — الهوية ثابتة حرفيًا.",
  ]
    .filter((l) => l !== null)
    .join("\n");
}

/**
 * تصدير حزمة الحلقة:
 *  ?format=zip   → ملف مضغوط كامل (الدستور + المصادر + صورها + تعليماتها + السرد + المشاهد + البرومبتات)
 *  ?format=md    → نص Markdown كامل
 *  ?format=json  → JSON خام لأي نظام آلي
 */
export async function GET(req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const format = req.nextUrl.searchParams.get("format") || "zip";

  const [ep] = await db.select().from(episodes).where(eq(episodes.id, id));
  if (!ep) return Response.json({ error: "الحلقة غير موجودة" }, { status: 404 });
  const sceneRows = await db.select().from(scenes).where(eq(scenes.episodeId, id)).orderBy(scenes.num);
  const allAssets = await db.select().from(assets).orderBy(assets.sortOrder);

  const md = buildEpisodeMarkdown(ep, sceneRows, allAssets);
  const fileBase = slug(`${ep.code}-${ep.title}`, ep.code);

  if (format === "md") {
    return new Response(md, {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
        "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(fileBase)}.md`,
      },
    });
  }

  if (format === "json") {
    return new Response(
      JSON.stringify({ episode: ep, scenes: sceneRows, identity: buildIdentityMarkdown(allAssets) }, null, 2),
      {
        headers: {
          "Content-Type": "application/json; charset=utf-8",
          "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(fileBase)}.json`,
        },
      }
    );
  }

  /* ─── ZIP ─── */
  const zip = new JSZip();

  zip.file(
    "README.txt",
    [
      "حزمة إنتاج — استوديو الهوية الثابتة",
      "═════════════════════════════════",
      `الحلقة: ${ep.code} — ${ep.title}`,
      "",
      "كيف تستخدم هذه الحزمة مع أي نموذج ذكاء؟",
      "1) ارفع ملفات 00-CONSTITUTION أولًا (الدستور + دليل الفن) — هي القانون الأعلى.",
      "2) ارفع محتوى REFERENCES ليعرف النموذج وجوه الشخصيات وأنماط الخرائط وفي كل مجلد INSTRUCTIONS خاصة بالصورة.",
      "3) الصق EPISODE-PACKAGE.md كاملًا — فيه السرد والمشاهد والبرومبتات الجاهزة.",
      "4) عند توليد مشهد: أرفق صور المراجع المذكورة في سطر [REF] ثم الصق البرومبت.",
      "",
      "القاعدة الذهبية: لا وجه ولا حدود من الخيال — كل شيء من هذه الحزمة حصرًا.",
    ].join("\n")
  );

  // الدستور والنمط
  const rule = allAssets.find((a) => a.type === "RULE");
  const style = allAssets.find((a) => a.type === "STYLE");
  zip.file("00-CONSTITUTION/RULE-constitution.txt", rule?.description || "—");
  zip.file("00-CONSTITUTION/STYLE-art-guide.txt", style?.description || "—");
  if (style?.styleLock) zip.file("00-CONSTITUTION/STYLE-LOCK.txt", style.styleLock);

  // المصادر المستخدمة + تعليمات كل صورة
  const usedIds = new Set<string>();
  for (const s of sceneRows) {
    ((s.characterIds as string[]) || []).forEach((c) => usedIds.add(c));
    ((s.propIds as string[]) || []).forEach((c) => usedIds.add(c));
    if (s.mapId) usedIds.add(s.mapId);
    if (s.bgId) usedIds.add(s.bgId);
  }
  const manifest: Record<string, unknown>[] = [];
  for (const a of allAssets) {
    if (!usedIds.has(a.id) && a.type !== "RULE" && a.type !== "STYLE" && a.type !== "MAP-STYLE") continue;
    const dir = `REFERENCES/${a.type}__${slug(a.nameEn || a.name, a.id.slice(0, 8))}`;
    const img = await readPublic(a.imagePath);
    if (img) {
      const ext = a.imagePath!.split(".").pop() || "png";
      zip.file(`${dir}/reference.${ext}`, img);
    }
    zip.file(`${dir}/INSTRUCTIONS.txt`, assetInstructions(a));
    manifest.push({ id: a.id, source: displayName(a), type: a.type, folder: dir, hasImage: !!img });
  }

  // السرد والحزمة النصية
  zip.file("01-NARRATIVE/narrative.txt", ep.narrative || "—");
  zip.file("01-NARRATIVE/director-notes.txt", ep.notes || "—");
  zip.file("EPISODE-PACKAGE.md", md);

  // المشاهد: برومبت + بيانات + الشريحة إن وُلّدت
  for (const s of sceneRows) {
    const dir = `SCENES/SCENE-${pad2(s.num)}-${slug(s.title, "scene")}`;
    zip.file(
      `${dir}/prompt.txt`,
      [`SCENE ${pad2(s.num)} — ${s.title}`, `السرد: ${s.narration}`, "", assemblePrompt(s)].join("\n")
    );
    zip.file(
      `${dir}/meta.txt`,
      [
        `التعبير: ${s.expression}`,
        `الكادر: ${s.camera}`,
        `الإضاءة: ${s.lighting}`,
        `الحالة: ${s.status}`,
        (s.missing as MissingRef[])?.length
          ? `نواقص: ${(s.missing as MissingRef[]).map((m) => `${m.kind} ← ${m.label}`).join(" | ")}`
          : null,
      ]
        .filter(Boolean)
        .join("\n")
    );
    const slide = await readPublic(s.imagePath);
    if (slide) {
      const ext = s.imagePath!.split(".").pop() || "png";
      zip.file(`${dir}/slide.${ext}`, slide);
    }
  }

  zip.file("MANIFEST.json", JSON.stringify({ episode: { code: ep.code, title: ep.title }, sources: manifest, sceneCount: sceneRows.length }, null, 2));

  const buf = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
  return new Response(new Uint8Array(buf), {
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename*=UTF-8''${encodeURIComponent(fileBase)}.zip`,
    },
  });
}
