import { db } from "@/db";
import { episodes, scenes } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

export async function GET() {
  const eps = await db.select().from(episodes).orderBy(desc(episodes.createdAt));
  const counts = await db
    .select({
      episodeId: scenes.episodeId,
      total: sql<number>`count(*)::int`,
      approved: sql<number>`count(*) filter (where ${scenes.status} = 'approved')::int`,
      generated: sql<number>`count(*) filter (where ${scenes.status} in ('generated','approved'))::int`,
    })
    .from(scenes)
    .groupBy(scenes.episodeId);

  const map = new Map(counts.map((c) => [c.episodeId, c]));
  return Response.json(
    eps.map((e) => ({
      ...e,
      sceneCount: map.get(e.id)?.total ?? 0,
      approvedCount: map.get(e.id)?.approved ?? 0,
      generatedCount: map.get(e.id)?.generated ?? 0,
    }))
  );
}

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body || !String(body.title ?? "").trim()) {
    return Response.json({ error: "عنوان الحلقة مطلوب" }, { status: 400 });
  }

  // توليد كود الحلقة التالي تلقائيًا: EP01, EP02 …
  const existing = await db.select({ code: episodes.code }).from(episodes);
  const max = existing.reduce((m, r) => {
    const match = /EP(\d+)/i.exec(r.code || "");
    return match ? Math.max(m, parseInt(match[1], 10)) : m;
  }, 0);
  const code = `EP${String(max + 1).padStart(2, "0")}`;

  const [row] = await db
    .insert(episodes)
    .values({
      code,
      title: String(body.title).trim(),
      narrative: String(body.narrative ?? ""),
      notes: String(body.notes ?? ""),
      status: "prep",
    })
    .returning();
  return Response.json(row, { status: 201 });
}
