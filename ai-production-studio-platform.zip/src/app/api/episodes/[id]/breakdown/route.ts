import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { runBreakdown } from "@/lib/breakdown";
import { NEGATIVE_DEFAULT, SEED_FALLBACK_STYLE_LOCK } from "@/lib/consts";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

type Ctx = { params: Promise<{ id: string }> };

/**
 * محرك تفكيك السرد: يقرأ نص الحلقة + الملاحظات الإخراجية
 * ويستدعي الشخصيات/الخرائط/العناصر من المكتبة حصرًا،
 * ثم يعيد بناء قائمة مشاهد الحلقة كاملةً ببرومبتات جاهزة.
 */
export async function POST(_req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const [ep] = await db.select().from(episodes).where(eq(episodes.id, id));
  if (!ep) return Response.json({ error: "الحلقة غير موجودة" }, { status: 404 });
  if (!ep.narrative.trim()) {
    return Response.json({ error: "أضف نص السرد أولاً قبل التفكيك" }, { status: 400 });
  }

  const allAssets = await db.select().from(assets).orderBy(assets.sortOrder);
  const styleAsset = allAssets.find((a) => a.type === "STYLE" && a.styleLock);
  const styleLock = styleAsset?.styleLock || SEED_FALLBACK_STYLE_LOCK;

  const result = runBreakdown({
    narrative: ep.narrative,
    notes: ep.notes,
    assets: allAssets,
    styleLock,
    negative: NEGATIVE_DEFAULT,
  });

  // إعادة بناء المشاهد من الصفر (المشاهد القديمة تُستبدل)
  await db.delete(scenes).where(eq(scenes.episodeId, id));
  if (result.scenes.length) {
    await db.insert(scenes).values(
      result.scenes.map((s) => ({
        episodeId: id,
        num: s.num,
        title: s.title,
        narration: s.narration,
        expression: s.expression,
        expressionEn: s.expressionEn,
        camera: s.camera,
        lighting: s.lighting,
        locationText: s.locationText,
        promptRef: s.promptRef,
        promptScene: s.promptScene,
        promptExpression: s.promptExpression,
        promptStyle: s.promptStyle,
        promptNegative: s.promptNegative,
        characterIds: s.characterIds,
        mapId: s.mapId,
        bgId: s.bgId,
        propIds: s.propIds,
        missing: s.missing,
        isMap: s.isMap,
        sortOrder: s.num,
        status: "draft",
      }))
    );
  }

  await db
    .update(episodes)
    .set({ status: ep.status === "prep" ? "production" : ep.status, updatedAt: new Date() })
    .where(eq(episodes.id, id));

  return Response.json({
    ok: true,
    count: result.scenes.length,
    missing: result.missing,
    summary: result.summary,
  });
}
