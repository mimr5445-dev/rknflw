import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const [ep] = await db.select().from(episodes).where(eq(episodes.id, id));
  if (!ep) return Response.json({ error: "غير موجودة" }, { status: 404 });
  const sceneRows = await db.select().from(scenes).where(eq(scenes.episodeId, id)).orderBy(scenes.num);
  const assetRows = await db.select().from(assets).orderBy(assets.sortOrder);
  return Response.json({ episode: ep, scenes: sceneRows, assets: assetRows });
}

const EDITABLE = ["code", "title", "narrative", "notes", "status", "favorite", "gates"] as const;

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "جسم غير صالح" }, { status: 400 });
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  for (const k of EDITABLE) if (k in body) patch[k] = body[k];
  const [row] = await db.update(episodes).set(patch).where(eq(episodes.id, id)).returning();
  if (!row) return Response.json({ error: "غير موجودة" }, { status: 404 });
  return Response.json(row);
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const [row] = await db.delete(episodes).where(eq(episodes.id, id)).returning({ id: episodes.id });
  if (!row) return Response.json({ error: "غير موجودة" }, { status: 404 });
  return Response.json({ ok: true });
}
