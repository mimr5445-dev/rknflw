import { db } from "@/db";
import { episodes, scenes } from "@/db/schema";
import { NEGATIVE_DEFAULT, SEED_FALLBACK_STYLE_LOCK } from "@/lib/consts";
import { desc, eq } from "drizzle-orm";
import { assets } from "@/db/schema";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

/** إضافة مشهد يدوي في نهاية الحلقة */
export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  if (!body?.episodeId) return Response.json({ error: "episodeId مطلوب" }, { status: 400 });

  const [ep] = await db.select().from(episodes).where(eq(episodes.id, body.episodeId));
  if (!ep) return Response.json({ error: "الحلقة غير موجودة" }, { status: 404 });

  const [last] = await db
    .select({ num: scenes.num })
    .from(scenes)
    .where(eq(scenes.episodeId, body.episodeId))
    .orderBy(desc(scenes.num))
    .limit(1);
  const num = (last?.num ?? 0) + 1;

  const [styleAsset] = await db
    .select()
    .from(assets)
    .where(eq(assets.type, "STYLE"))
    .limit(1);

  const [row] = await db
    .insert(scenes)
    .values({
      episodeId: body.episodeId,
      num,
      title: `مشهد يدوي ${num}`,
      narration: "",
      promptStyle: styleAsset?.styleLock || SEED_FALLBACK_STYLE_LOCK,
      promptNegative: NEGATIVE_DEFAULT,
      sortOrder: num,
      status: "draft",
    })
    .returning();
  return Response.json(row, { status: 201 });
}
