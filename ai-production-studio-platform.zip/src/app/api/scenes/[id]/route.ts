import { db } from "@/db";
import { scenes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { NextRequest } from "next/server";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const EDITABLE = [
  "num",
  "title",
  "narration",
  "expression",
  "expressionEn",
  "camera",
  "lighting",
  "locationText",
  "promptRef",
  "promptScene",
  "promptExpression",
  "promptStyle",
  "promptNegative",
  "status",
  "imagePath",
  "notes",
  "characterIds",
  "mapId",
  "bgId",
  "propIds",
  "missing",
  "isMap",
  "sortOrder",
] as const;

export async function PATCH(req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "جسم غير صالح" }, { status: 400 });
  const patch: Record<string, unknown> = { updatedAt: new Date() };
  for (const k of EDITABLE) if (k in body) patch[k] = body[k];
  const [row] = await db.update(scenes).set(patch).where(eq(scenes.id, id)).returning();
  if (!row) return Response.json({ error: "غير موجود" }, { status: 404 });
  return Response.json(row);
}

export async function DELETE(_req: NextRequest, { params }: Ctx) {
  const { id } = await params;
  const [row] = await db.delete(scenes).where(eq(scenes.id, id)).returning({ id: scenes.id });
  if (!row) return Response.json({ error: "غير موجود" }, { status: 404 });
  return Response.json({ ok: true });
}
