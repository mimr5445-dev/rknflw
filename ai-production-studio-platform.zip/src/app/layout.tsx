import type { Metadata } from "next";
import type { ReactNode } from "react";
import { Cairo, IBM_Plex_Sans_Arabic, JetBrains_Mono } from "next/font/google";
import { SiteNav } from "@/components/nav";
import "./globals.css";

const cairo = Cairo({ subsets: ["arabic", "latin"], variable: "--font-cairo" });
const plex = IBM_Plex_Sans_Arabic({
  subsets: ["arabic"],
  weight: ["300", "400", "500", "600", "700"],
  variable: "--font-plex",
});
const jet = JetBrains_Mono({ subsets: ["latin"], variable: "--font-jet", weight: ["400", "700", "800"] });

export const metadata: Metadata = {
  title: "استوديو الهوية الثابتة — خط إنتاج المشاهد",
  description:
    "نظام إنتاج متكامل يحوّل NotebookLM إلى استوديو بهوية بصرية ثابتة: مصادر مقدسة، مختبر شخصيات، خط إنتاج ببوابات جودة، عارض شرائح، وتصدير كامل.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${cairo.variable} ${plex.variable} ${jet.variable}`}>
      <body className="min-h-screen antialiased">
        <div className="studio-bg" />
        <SiteNav />
        <main className="mx-auto w-full max-w-[1400px] px-4 pb-24 pt-6 sm:px-6 lg:px-10">{children}</main>
      </body>
    </html>
  );
}
