import { db } from "@/db";
import { assets } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { LabClient } from "@/components/lab-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "المختبر — استوديو الهوية الثابتة" };

export default async function LabPage({
  searchParams,
}: {
  searchParams: Promise<{ type?: string; name?: string }>;
}) {
  await ensureSeeded();
  const all = await db.select().from(assets).orderBy(assets.sortOrder);
  const sp = await searchParams;
  return <LabClient assets={all} prefillType={sp.type ?? null} prefillName={sp.name ?? null} />;
}
