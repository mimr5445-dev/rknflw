import { notFound } from "next/navigation";
import { db } from "@/db";
import { episodes, scenes } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { SlidesClient } from "@/components/slides-client";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

export const metadata = { title: "عرض الشرائح — استوديو الهوية الثابتة" };

export default async function SlidesPage({ params }: { params: Promise<{ id: string }> }) {
  await ensureSeeded();
  const { id } = await params;
  const [ep] = await db.select().from(episodes).where(eq(episodes.id, id));
  if (!ep) notFound();
  const sceneRows = await db.select().from(scenes).where(eq(scenes.episodeId, id)).orderBy(scenes.num);
  return <SlidesClient episode={ep} scenes={sceneRows} />;
}
