import { db } from "@/db";
import { assets } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { LibraryClient } from "@/components/library-client";

export const dynamic = "force-dynamic";

export const metadata = { title: "المكتبة المقدسة — استوديو الهوية الثابتة" };

export default async function LibraryPage() {
  await ensureSeeded();
  const all = await db.select().from(assets).orderBy(assets.type, assets.sortOrder);
  return <LibraryClient initialAssets={all} />;
}
