import Link from "next/link";
import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { episodeStatusMeta, typeColor, typeLabel } from "@/lib/studio";
import { desc, eq, sql } from "drizzle-orm";
import {
  ArrowLeft,
  BrainCircuit,
  Clapperboard,
  FileArchive,
  FlaskConical,
  Image as ImageIcon,
  LibraryBig,
  Map as MapIcon,
  Play,
  ShieldCheck,
  Sparkles,
  UserRound,
  Workflow,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  await ensureSeeded();

  const allAssets = await db.select().from(assets).orderBy(assets.sortOrder);
  const allEpisodes = await db.select().from(episodes).orderBy(desc(episodes.createdAt));
  const sceneRows = await db.select({ status: scenes.status, episodeId: scenes.episodeId }).from(scenes);

  const byType = (t: string) => allAssets.filter((a) => a.type === t);
  const favs = allAssets.filter((a) => a.favorite).slice(0, 6);
  const approved = sceneRows.filter((s) => s.status === "approved").length;

  const stats = [
    { label: "مصدر مقدس", value: allAssets.length, icon: ShieldCheck, color: "#E9B44C" },
    { label: "شخصية في الحقيبة", value: byType("CHAR").length, icon: UserRound, color: "#8B5CF6" },
    { label: "خريطة في الأطلس", value: byType("MAP").length, icon: MapIcon, color: "#2DD4BF" },
    { label: "حلقة إنتاج", value: allEpisodes.length, icon: Clapperboard, color: "#60A5FA" },
    { label: "مشهد مخطط", value: sceneRows.length, icon: Workflow, color: "#FB923C" },
    { label: "شريحة معتمدة", value: approved, icon: Sparkles, color: "#4ADE80" },
  ];

  const pipeline = [
    {
      n: "01",
      title: "العقل — NotebookLM",
      desc: "الدستور + المصادر المقدسة يقرران: أي شخصية، أي تعبير، أي كادر — بلا اختراع وبلا استعارة وجوه.",
      icon: BrainCircuit,
      color: "#E9B44C",
      href: "/guide",
      cta: "تعليمات NotebookLM",
    },
    {
      n: "02",
      title: "اليد — أداة التوليد",
      desc: "ارفع صورة المرجع نفسها مع برومبت المشهد في كل مرة — هكذا تعيش الهوية سنتين لا حلقتين.",
      icon: ImageIcon,
      color: "#2DD4BF",
      href: "/production",
      cta: "افتح خط الإنتاج",
    },
    {
      n: "03",
      title: "التجسيد — المونتاج",
      desc: "شرائح مرقمة بالترتيب → تحريك بسيط → فيديو واحد بهوية يعرفها المتابع قبل أن تذكر الاسم.",
      icon: Clapperboard,
      color: "#8B5CF6",
      href: "/production",
      cta: "شاهد المشاهد",
    },
  ];

  return (
    <div className="space-y-10">
      {/* ═══ البطل ═══ */}
      <section className="glass relative overflow-hidden rounded-[2rem] px-6 py-12 sm:px-12">
        <div
          className="pointer-events-none absolute -top-32 left-1/2 h-72 w-[46rem] -translate-x-1/2 rounded-full opacity-30 blur-3xl"
          style={{ background: "radial-gradient(closest-side, #E9B44C, transparent)" }}
        />
        <p className="sec-num mb-4">FIXED IDENTITY STUDIO — خط الإنتاج المقدس</p>
        <h1 className="display max-w-3xl text-4xl leading-[1.25] text-white sm:text-5xl">
          نفس الوجه. نفس الخريطة. نفس النمط.
          <span className="bg-gradient-to-l from-gold-400 to-[#f6dd9f] bg-clip-text text-transparent"> في كل حلقة.</span>
        </h1>
        <p className="mt-5 max-w-2xl text-[15px] leading-8 text-zinc-400">
          هذا الاستوديو يحوّل خطتك إلى واقع عملي: مكتبة مصادر مقدسة يفهمها NotebookLM، مختبر لصناعة الشخصيات
          وأوراق التعابير، محرك تفكيك يحوّل السرد إلى مشاهد ببرومبتات جاهزة، بوابات جودة قبل التوليد،
          وتصدير كامل (PDF / نص / ZIP) يجعل أي نموذج ذكاء يفهم مشروعك ويبنيه معك.
        </p>
        <div className="mt-8 flex flex-wrap gap-3">
          <Link href="/production" className="btn btn-gold">
            <Play className="size-4" /> ابدأ الإنتاج
          </Link>
          <Link href="/lab" className="btn btn-ghost">
            <FlaskConical className="size-4" /> المختبر
          </Link>
          <a href="/api/export/library?format=zip" className="btn btn-teal">
            <FileArchive className="size-4" /> حزمة الهوية ZIP
          </a>
        </div>
      </section>

      {/* ═══ المعمارية ═══ */}
      <section>
        <div className="mb-5 flex items-end justify-between">
          <div>
            <p className="sec-num mb-2">ARCHITECTURE</p>
            <h2 className="display text-2xl text-white">المعمارية الصحيحة للخطتك</h2>
          </div>
          <p className="hidden max-w-xs text-xs leading-6 text-zinc-500 sm:block">
            NotebookLM عقل لا يد — والثبات الحقيقي يأتي من رفع المرجع نفسه مع كل مشهد.
          </p>
        </div>
        <div className="grid gap-4 md:grid-cols-3">
          {pipeline.map((p) => (
            <Link key={p.n} href={p.href} className="glass glass-hover group relative overflow-hidden rounded-3xl p-6">
              <span
                className="pointer-events-none absolute -left-4 -top-8 font-mono-en text-[7rem] font-extrabold leading-none opacity-[0.05]"
                dir="ltr"
              >
                {p.n}
              </span>
              <span
                className="mb-5 grid size-12 place-items-center rounded-2xl"
                style={{ background: `${p.color}18`, color: p.color, border: `1px solid ${p.color}33` }}
              >
                <p.icon className="size-6" />
              </span>
              <h3 className="display text-lg text-white">{p.title}</h3>
              <p className="mt-2 text-[13px] leading-7 text-zinc-400">{p.desc}</p>
              <span className="mt-4 inline-flex items-center gap-1 text-xs font-bold" style={{ color: p.color }}>
                {p.cta}
                <ArrowLeft className="size-3.5 transition-transform group-hover:-translate-x-1" />
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* ═══ الإحصاءات ═══ */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {stats.map((s) => (
          <div key={s.label} className="glass glass-hover rounded-2xl p-4 text-center">
            <s.icon className="mx-auto mb-2 size-5" style={{ color: s.color }} />
            <div className="display text-3xl text-white" dir="ltr">
              {s.value}
            </div>
            <div className="mt-1 text-[11px] font-bold text-zinc-500">{s.label}</div>
          </div>
        ))}
      </section>

      {/* ═══ الحلقات والمقدس ═══ */}
      <div className="grid gap-6 lg:grid-cols-2">
        <section className="glass rounded-3xl p-6">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="display text-lg text-white">آخر الحلقات</h2>
            <Link href="/production" className="text-xs font-bold text-gold-400 hover:underline">
              كل الحلقات ←
            </Link>
          </div>
          <div className="space-y-3">
            {allEpisodes.slice(0, 4).map((ep) => {
              const meta = episodeStatusMeta(ep.status);
              const total = sceneRows.filter((s) => s.episodeId === ep.id).length;
              return (
                <Link
                  key={ep.id}
                  href={`/production/${ep.id}`}
                  className="glass-hover flex items-center gap-4 rounded-2xl border border-white/[0.06] bg-white/[0.02] p-4"
                >
                  <span className="font-mono-en text-xs font-bold text-gold-500" dir="ltr">
                    {ep.code}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-white">{ep.title}</p>
                    <p className="text-[11px] text-zinc-500">{total} مشهد</p>
                  </div>
                  <span
                    className="chip"
                    style={{ color: meta.color, borderColor: `${meta.color}55`, background: `${meta.color}14` }}
                  >
                    {meta.label}
                  </span>
                </Link>
              );
            })}
            {!allEpisodes.length && (
              <p className="py-8 text-center text-sm text-zinc-500">لا حلقات بعد — أنشئ أول حلقة من خط الإنتاج.</p>
            )}
          </div>
        </section>

        <section className="glass rounded-3xl p-6">
          <div className="mb-5 flex items-center justify-between">
            <h2 className="display text-lg text-white">المصادر المقدسة المميزة</h2>
            <Link href="/library" className="flex items-center gap-1 text-xs font-bold text-gold-400 hover:underline">
              <LibraryBig className="size-3.5" /> المكتبة كاملة ←
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {favs.map((a) => (
              <div key={a.id} className="glass-hover relative overflow-hidden rounded-2xl border border-white/[0.06] bg-white/[0.02]">
                {a.imagePath ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={a.imagePath} alt={a.name} className="h-24 w-full object-cover" />
                ) : (
                  <div className="grid h-24 place-items-center" style={{ background: `${typeColor(a.type)}12` }}>
                    <span className="font-mono-en text-[10px] font-bold tracking-widest" style={{ color: typeColor(a.type) }} dir="ltr">
                      {a.type}
                    </span>
                  </div>
                )}
                <div className="p-2.5">
                  <p className="truncate text-[11px] font-bold text-white">{a.name}</p>
                  <p className="truncate text-[10px] text-zinc-500">{typeLabel(a.type)}</p>
                </div>
              </div>
            ))}
            {!favs.length && <p className="col-span-full py-8 text-center text-sm text-zinc-500">ميّز مصادرك المقدسة بنجمة لتظهر هنا.</p>}
          </div>
        </section>
      </div>
    </div>
  );
}
