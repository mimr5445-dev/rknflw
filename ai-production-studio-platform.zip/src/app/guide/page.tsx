import { db } from "@/db";
import { assets } from "@/db/schema";
import { ensureSeeded } from "@/db/seed";
import { GuideClient } from "@/components/guide-client";
import { SOURCE_TYPES } from "@/lib/studio";
import {
  AlertOctagon,
  BookOpenCheck,
  BrainCircuit,
  CircleCheck,
  Clapperboard,
  FolderTree,
  Image as ImageIcon,
  Landmark,
  Map,
  MessagesSquare,
  Repeat,
  ShieldCheck,
  TestTube2,
  Wand2,
} from "lucide-react";

export const dynamic = "force-dynamic";

export const metadata = { title: "الدليل والتعليمات — استوديو الهوية الثابتة" };

const TRUTHS = [
  {
    icon: BrainCircuit,
    title: "NotebookLM عقل، لا يد",
    desc: "يقرأ المصادر ويقرر (أي شخصية، أي تعبير، أي برومبت) — لكنه لا يولّد صورًا حرة. الرسم يحدث في أداة التوليد.",
  },
  {
    icon: ShieldCheck,
    title: "الثبات يأتي من رفع المرجع نفسه",
    desc: "لا نص في العالم يضمن نفس الوجه كتابةً — السر: ترفع الصورة المرجعية لنموذج التوليد مع كل مشهد، كما يرفع المخرج صورة الممثل لفريق المكياج.",
  },
  {
    icon: Repeat,
    title: "حلقة = محادثة جديدة",
    desc: "الدفتر واحد لا يتغير، وكل حلقة محادثة جديدة حتى لا تختلط ذاكرة القصص وتتسرب الشخصيات.",
  },
];

const STAGES = [
  {
    n: "01",
    title: "بناء الدفتر وبروتوكول التسمية",
    icon: Landmark,
    points: [
      "دفتر «الاستوديو المركزي — الهوية المقدسة» لا يتغير أبدًا — هو المقر وليس مكان الحلقات.",
      "كل مصدر يُسمّى ببادئته الرسمية ليستشهد بها NotebookLM في إجاباته — وأي اسم بلا استشهاد = اختراع يُرفض.",
      "ترتيب الرفع: RULE أولاً ثم STYLE ثم CHAR ثم أوراق التعابير ثم الخرائط ثم BG وPROP.",
    ],
  },
  {
    n: "02",
    title: "قاعدتا الذهب: الخرائط وأوراق التعابير",
    icon: Map,
    points: [
      "الخريطة تُعدَّل ولا تُولَّد: تولدها مرة واحدة مثالية، وفي كل مشهد تُرفع نفسها مع «أضف الأسهم والأعلام فقط».",
      "ورقة التعابير أقوى من الكلام: شبكة الوجوه الستة تُولد من المرجع نفسه، ويصبح مرجع المشهد هو الوجه المطلوب أصلًا.",
    ],
  },
  {
    n: "03",
    title: "الدستور — مصدر RULE",
    icon: BookOpenCheck,
    points: [
      "يجبر النموذج على الإنتاج لا التلخيص، وعلى الإخراج بصيغة الكتلة حصرًا (السرد/الممثلون/التعبير/الكادر/الإضاءة/البرومبت).",
      "يمنع اختراع الشخصيات والحدود والاستعارة، ويسجل النواقص بدل ارتجالها.",
      "مولّد التعليمات أدناه يعطيك الدستور كاملًا جاهزًا للصق.",
    ],
  },
  {
    n: "04",
    title: "دورة إنتاج الحلقة",
    icon: Clapperboard,
    points: [
      "محادثة جديدة ← «الوضع: إنتاج حلقة» ← أرسل السرد بالقالب ← راجع المخرج بدقيقتين بقائمة البوابات.",
      "ولّد الشرائح: ارفع المرجع + الصق البرومبت ← احفظ باسم منظم EP01-SC03-ترامب-غضب.",
      "قارن ثانيتين بجانب المرجع — أي انحراف = إعادة توليد مع جملة التثبيت.",
    ],
  },
  {
    n: "05",
    title: "أداة التوليد — اليد التي ترسم",
    icon: ImageIcon,
    points: [
      "Gemini: الأسهل لدورة «ارفع مرجعًا + الصق برومبتًا»، وممتاز لتعديل التعابير والخرائط.",
      "Midjourney بخياري cref/sref للثبات الفني الأقصى — أو Leonardo بإدارة مكتبة الشخصيات.",
      "Video Overviews مسار مساعد لضبط الإيقاع (animatic) — وليس خط الإنتاج الرئيسي.",
    ],
  },
  {
    n: "06",
    title: "الصيانة والتحصين",
    icon: TestTube2,
    points: [
      "حلقة تجريبية من 5 مشاهد قبل الإنتاج — كل عيب يتحول إلى جملة منع جديدة في الدستور الحي.",
      "المكتبة تُبنى تدريجيًا: ارفع شخصيات الحلقة القادمة فقط، وستكتمل الحقيبة بالخبرة.",
      "اختبار المتابع: أخفِ الاسم — من يُعرف من شكله نجحت هويته.",
    ],
  },
];

const FATAL = [
  { t: "الاعتماد على البرومبت وحده", d: "بدون رفع المرجع تنحرف الوجوه تدريجيًا — [REF] إلزامي بلا استثناء." },
  { t: "محادثة واحدة طويلة لكل الحلقات", d: "ذاكرة القصص تختلط وتتسرب الشخصيات — محادثة جديدة لكل حلقة." },
  { t: "توليد خرائط جديدة كل مرة", d: "جغرافيا منحرفة ومتناقضة — الأطلس المعد مسبقًا + قاعدة «تُعدَّل لا تُولَّد»." },
  { t: "تسمية عشوائية للمصادر", d: "«صورة 1» و«Screenshot» تجعل النموذج أعمى — بروتوكول التسمية بلا استثناء." },
  { t: "الاستسلام بعد أول حلقة", d: "النظام يحتاج حلقة تضبيط واحدة — ثم يعمل كخط إنتاج حقيقي." },
];

export default async function GuidePage() {
  await ensureSeeded();
  const all = await db.select().from(assets).orderBy(assets.sortOrder);
  const rule = all.find((a) => a.type === "RULE");
  const style = all.find((a) => a.type === "STYLE");
  const styleLock = style?.styleLock ?? "";

  return (
    <div className="space-y-12">
      {/* الترويسة */}
      <section className="glass rounded-[2rem] p-8 sm:p-12">
        <p className="sec-num mb-3">THE PLAYBOOK</p>
        <h1 className="display max-w-3xl text-4xl leading-[1.3] text-white">
          كيف يفكر الاستوديو وكيف ينتج — <span className="text-gold-400">الخطة كاملة كما صُممت</span>
        </h1>
        <p className="mt-4 max-w-2xl text-sm leading-8 text-zinc-400">
          هذه الصفحة هي روح خطتك داخل التطبيق: الحقائق التقنية، المراحل الست، بروتوكول التسمية، والأخطاء القاتلة —
          وفي الأسفل مولّد يجهّز لك تعليمات NotebookLM من مكتبتك الحية مباشرة.
        </p>
      </section>

      {/* الحقائق الثلاث */}
      <section className="grid gap-4 md:grid-cols-3">
        {TRUTHS.map((t) => (
          <div key={t.title} className="glass glass-hover rounded-3xl p-6">
            <t.icon className="mb-4 size-7 text-gold-400" />
            <h3 className="display text-lg leading-7 text-white">{t.title}</h3>
            <p className="mt-2 text-[13px] leading-7 text-zinc-400">{t.desc}</p>
          </div>
        ))}
      </section>

      {/* بروتوكول التسمية */}
      <section className="glass overflow-hidden rounded-3xl">
        <div className="border-b border-white/[0.07] p-6">
          <h2 className="display flex items-center gap-2 text-2xl text-white">
            <FolderTree className="size-6 text-gold-400" /> بروتوكول تسمية المصادر
          </h2>
          <p className="mt-1 text-[13px] text-zinc-500">أهم جدول في المشروع كله — تُستخدم هذه البادئات حرفيًا في كل مكان.</p>
        </div>
        <div className="grid gap-px bg-white/[0.05] sm:grid-cols-2 lg:grid-cols-4">
          {SOURCE_TYPES.map((t) => (
            <div key={t.key} className="bg-ink-900 p-5">
              <span className="chip" style={{ color: t.color, borderColor: `${t.color}55`, background: `${t.color}14` }} dir="ltr">
                {t.key}
              </span>
              <p className="mt-3 text-sm font-bold text-white">{t.label}</p>
              <p className="mt-1 text-[11px] leading-5 text-zinc-500">{t.hint}</p>
              <p className="mt-2 font-mono-en text-[10px] text-zinc-600" dir="ltr">
                {t.key} — الاسم — الوظيفة
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* المراحل الست */}
      <section>
        <p className="sec-num mb-2">SIX STAGES</p>
        <h2 className="display mb-6 text-2xl text-white">مراحل بناء النظام</h2>
        <div className="grid gap-4 md:grid-cols-2">
          {STAGES.map((s) => (
            <article key={s.n} className="glass glass-hover relative overflow-hidden rounded-3xl p-6">
              <span className="pointer-events-none absolute -left-3 -top-7 font-mono-en text-[6rem] font-extrabold opacity-[0.05]" dir="ltr">
                {s.n}
              </span>
              <s.icon className="mb-4 size-6 text-gold-400" />
              <h3 className="display text-lg text-white">{s.title}</h3>
              <ul className="mt-3 space-y-2">
                {s.points.map((p) => (
                  <li key={p} className="flex items-start gap-2 text-[12.5px] leading-6 text-zinc-400">
                    <CircleCheck className="mt-1 size-3.5 shrink-0 text-tealx-400" />
                    {p}
                  </li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      {/* مولد التعليمات */}
      <GuideClient assets={all} ruleText={rule?.description ?? ""} styleLock={styleLock} />

      {/* الأخطاء الخمسة */}
      <section>
        <p className="sec-num mb-2 !text-hotpink-500">FATAL FIVE</p>
        <h2 className="display mb-6 flex items-center gap-2 text-2xl text-white">
          <AlertOctagon className="size-6 text-hotpink-500" /> الأخطاء الخمسة التي تقتل المشروع
        </h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          {FATAL.map((f, i) => (
            <div key={f.t} className="glass glass-hover rounded-3xl border-hotpink-500/20 p-5">
              <span className="font-mono-en text-2xl font-extrabold text-hotpink-500/60" dir="ltr">
                {String(i + 1).padStart(2, "0")}
              </span>
              <h4 className="display mt-2 text-[15px] leading-6 text-white">{f.t}</h4>
              <p className="mt-2 text-[12px] leading-6 text-zinc-400">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="glass flex flex-wrap items-center justify-between gap-4 rounded-3xl p-8">
        <div>
          <h3 className="display flex items-center gap-2 text-xl text-white">
            <MessagesSquare className="size-5 text-gold-400" /> جاهز للتجربة؟
          </h3>
          <p className="mt-2 max-w-xl text-sm leading-7 text-zinc-400">
            ابدأ بالحلقة التجريبية: 5 مشاهد كاملة الدورة — كل خطأ يظهر يتحول فورًا إلى جملة منع في الدستور.
          </p>
        </div>
        <div className="flex gap-2">
          <a href="/production" className="btn btn-gold">
            <Wand2 className="size-4" /> افتح خط الإنتاج
          </a>
        </div>
      </section>
    </div>
  );
}
