import { db } from "@/db";
import { assets, episodes, scenes } from "@/db/schema";
import { runBreakdown } from "@/lib/breakdown";
import { NEGATIVE_DEFAULT } from "@/lib/studio";
import { sql } from "drizzle-orm";

const CONSTITUTION = `أنت "استوديو الهوية الثابتة" — مخرج استوري بورد يعمل بنظام مصادر مغلق. أنت خط إنتاج، لا مُلخّص ولا مُعلّم.

القاعدة صفر: المصادر في هذا الدفتر هي العالم الوحيد. كل شخصية، خريطة، عنصر، أو نمط فني تأتيه من المصادر حصراً. ما ليس له مصدر لا يُخترع له شكل — يُسجَّل في "نواقص مطلوبة".

بروتوكول المصادر:
- المصادر نوعها معروف من اسمها: RULE / STYLE / CHAR / CHAR-EXP / MAP / MAP-STYLE / BG / PROP.
- المصدر "CHAR — الاسم — الوظيفة" هو الوجه الرسمي الوحيد لهذه الشخصية في هذا المشروع وعبر كل الحلقات.
- ممنوع منعاً باتاً استخدام مرجع شخصية لدور آخر.
- إذا ذُكر في السرد شخص أو عنصر ليس له مصدر: لا تخترع شكله، ولا تستعير وجه شخصية أخرى. اكتبه في "نواقص مطلوبة: أنشئ مرجع CHAR/PROP لـ …".
- الخريطة: لا تُخترع خريطة جديدة أبداً. المشهد الذي يذكر دولة/قارة يستخدم مصدر MAP المطابق إن وُجد. إن لم يوجد: استخدم MAP-STYLE مع إعلان في "نواقص مطلوبة". ممنوع رسم حدود مخترعة.

مهمتك عند إرسال سرد/قصة:
1) قسّمه إلى مشاهد: كل مشهد = مكان واحد + حدث واحد + انفعال واحد سائد.
2) لكل مشهد أخرج الكتلة: السرد / الممثلون من المصادر / التعبير المطاطي / الكادر / الإضاءة المزاجية / برومبت التوليد (EN) بحقول [REF] و[SCENE] و[EXPRESSION] و[STYLE LOCK] و[NEGATIVE].
3) في نهاية كل رد: جدول ملخص + نواقص مطلوبة + سطر تأكيد الاستمرارية.

ممنوعات مطلقة: شرح المصادر أو تلخيصها — الخروج عن صيغة الكتلة — اختراع شخصيات أو حدود — عبارات "بأسلوب مشابه" — مقدمات أدبية. عند أي غموض: اختر الأقوى درامياً وأكمل مع سطر يشرح اختيارك.

عند بدء محادثة جديدة وكتابة "الوضع: إنتاج حلقة": أجب بسطر واحد "الاستوديو جاهز — أرسل السرد" ثم انتظر.`;

const STYLE_GUIDE = `STYLE LOCK: flat 2D rubber-face caricature, thick clean black outlines, solid flat colors, exaggerated stretchy facial expressions, simple oval eyes, no nose, no lips, matte paper background, cinematic flat lighting, 16:9 frame

دليل الفن والوجه المطاطي: الهوية تُقفل من الصورة المرجعية، والتعبير يتغير من خلال ثلاثة عناصر فقط: العينان، الحاجبان، الفم — بقية الوجه والشعر والملابس ثابتة حرفيًا بين كل المشاهد وكل الحلقات.

جدول التعابير المعتمدة: محايد / انزعاج / غضب / انفجار / فرح / بكاء / صدمة / سخرية.

الإضاءة المزاجية: تيل محايد سينمائي / غسل أحمر للغضب / أزرق بارد للحزن / فلاش قاسٍ للصدمة / دفء ذهبي للنصر.

قاعدة داخلية: سطر STYLE LOCK في أول هذا الملف يُنسخ حرفيًا كلمة بكلمة في خانة [STYLE LOCK] في كل برومبت، ممنوع إعادة صياغته أو اختصاره أو ترجمته.`;

export const SEED_STYLE_LOCK =
  "flat 2D rubber-face caricature, thick clean black outlines, solid flat colors, exaggerated stretchy facial expressions, simple oval eyes, no nose, no lips, matte paper background, cinematic flat lighting, 16:9 frame";

const WWI_NARRATIVE = `في سراييفو عام 1914 وقف وريث عرش النمسا-المجر فرانز فرديناند في شارع مزدحم، ثم دوّت رصاصة غافريلو برينسيب فاهتزت أوروبا كلها بصدمة لم تعرف مثلها.
انتقل الخبر إلى أوروبا، وعلى خريطة القارة بدأت الدول تحسب مواقعها وحدودها، فأوروبا كانت برميل بارود ينتظر شرارة.
في برلين ثار القيصر فيلهلم الثاني غاضبًا وتوعد صربيا بالويل، وارتفعت الأصوات في أروقة القصر تطالب بالحرب.
وجهت النمسا-المجر إنذارًا مهينًا إلى صربيا، فانزعجت عواصم أوروبا وتحركت الجيوش بهدوء نحو الحدود.
على خريطة أوروبا 1914 انقسمت القارة إلى معسكرين، وتحولت الخطوط على الورق إلى جبهات حقيقية من فرنسا إلى روسيا.
أُعلنت الحرب رسميًا، وانفجرت القارة في أعنف صراع شهدته البشرية حتى تلك اللحظة.
في الخنادق الموحلة على الجبهة الغربية بكى الجنود أوطانهم تحت مطر لا يتوقف، وانهار العالم القديم إلى الأبد.`;

const WWI_NOTES = `المشاهد التي فيها خريطة استخدم MAP — أوروبا 1914. مشهد الاغتيال: صدمة بمستوى انفجار. المشهد الأخير: انهيار بكاء في الخندق.`;

let seeded = false;

export async function ensureSeeded(): Promise<void> {
  if (seeded) return;
  try {
    const rows = await db.execute(sql`select count(*)::int as n from assets`);
    const n = (rows.rows?.[0] as { n?: number })?.n ?? 0;
    if (n > 0) {
      seeded = true;
      return;
    }

    const inserted = await db
      .insert(assets)
      .values([
        {
          type: "RULE",
          name: "دستور الاستوديو",
          role: "القانون الأعلى للإنتاج",
          description: CONSTITUTION,
          prompt:
            "يُرفع أولاً في دفتر NotebookLM باسم «RULE — دستور الاستوديو» ولا يُعدَّل إلا بعد كل عيب يظهر في الإنتاج — الدستور وثيقة حية تتضخم بأخطائك الحقيقية.",
          sortOrder: 1,
          favorite: true,
        },
        {
          type: "STYLE",
          name: "دليل الفن والوجه المطاطي",
          role: "الهوية البصرية الموحدة",
          nameEn: "Rubber-face art bible",
          description: STYLE_GUIDE,
          styleLock: SEED_STYLE_LOCK,
          prompt:
            "يُرفع ثانيًا باسم «STYLE — دليل الفن والوجه المطاطي». سطر STYLE LOCK يُلصق حرفيًا في كل برومبت توليد.",
          sortOrder: 2,
          favorite: true,
        },
        {
          type: "CHAR",
          name: "ترامب",
          role: "رئيس الولايات المتحدة 2017–2021",
          nameEn: "Donald Trump",
          imagePath: "/seed/char-statesman.png",
          description:
            "قفل الهوية: شعر أشقر ممشط للخلف، بدلة كحلية، ربطة حمراء طويلة، دبوس العلم الأمريكي على الصدر. الوجه الرسمي الوحيد عبر كل الحلقات.",
          prompt:
            "أرفق هذه الصورة نفسها مع كل مشهد يذكر الشخصية. عند تغيير التعبير: العينان والحاجبان والفم فقط يتغيران — الشعر والبدلة والربطة والدبوس ثابتة حرفيًا. عند أي انحراف أعد التوليد مع: keep identical face, hair, suit, and pin as the attached reference.",
          sortOrder: 10,
          favorite: true,
        },
        {
          type: "CHAR",
          name: "فرانز فرديناند",
          role: "وريث عرش النمسا-المجر",
          nameEn: "Archduke Franz Ferdinand",
          imagePath: "/seed/char-archduke.png",
          description:
            "قفل الهوية: شنب كثيف معقوف، زي عسكري أخضر داكن بياقة حمراء، قبعة بريش النعام، ميداليات صدر.",
          prompt:
            "أرفق هذه الصورة مع مشاهد سراييفو 1914. الحفاظ على الشنب المعقوف والزي العسكري والميداليات إلزامي.",
          sortOrder: 11,
        },
        {
          type: "CHAR",
          name: "فيلهلم الثاني",
          role: "قيصر ألمانيا",
          nameEn: "Kaiser Wilhelm II",
          imagePath: "/seed/char-kaiser.png",
          description:
            "قفل الهوية: خوذة ذات رأس مدبب (Pickelhaube)، شارب معقوف للأعلى، زي عسكري أزرق داكن بميداليات.",
          prompt:
            "أرفق هذه الصورة مع مشاهد برلين. الخوذة المدببة والشارب المعقوف خطان أحمران — لا يتغيران أبدًا.",
          sortOrder: 12,
        },
        {
          type: "CHAR-EXP",
          name: "ترامب — ورقة التعابير",
          role: "التعابير الستة المعتمدة",
          nameEn: "Trump expression sheet",
          imagePath: "/seed/exp-sheet.png",
          description:
            "شبكة التعابير الستة من المرجع نفسه: محايد / غضب / انفجار / فرح / بكاء / صدمة. عند المشهد، مرجع أداة التوليد هو الوجه المطلوب أصلًا — ورقة التعابير أقوى من الكلام.",
          prompt:
            "وُلّدت مرة واحدة من مرجع الشخصية نفسه. استخدم الإطار المطابق لتعبير المشهد كمرجع مرفق بدل وصف التعبير نصيًا فقط.",
          sortOrder: 13,
        },
        {
          type: "MAP",
          name: "أوروبا — أطلس الحروب",
          era: "1914",
          role: null,
          nameEn: "Europe 1914 atlas map",
          imagePath: "/seed/map-europe-1914.png",
          description:
            "الحقيقة الجغرافية الوحيدة لمشاهد الحرب العالمية الأولى. وُلّدت مرة واحدة بشكل مثالي وأُغلقت.",
          prompt:
            "الخريطة تُعدَّل ولا تُولَّد: أرفق نفس الصورة مع كل مشهد خريطة واطلب إضافة الأسهم والأعلام والانفجارات فقط — ممنوع تغيير السواحل والحدود.",
          sortOrder: 20,
          favorite: true,
        },
        {
          type: "MAP-STYLE",
          name: "نمط الخرائط الرسمي",
          role: "عين اللون والخط والإضاءة",
          nameEn: "Official cartography style",
          imagePath: "/seed/map-europe-1914.png",
          description:
            "مرجع اللون والخط والإضاءة لأي خريطة جديدة (دولة/قارة يذكرها المشهد ولا أطلس لها بعد). يُطبَّق على النمط فقط — ممنوع استعارته كحدود.",
          prompt: "عند غياب MAP مطابق: استخدم هذا النمط للألوان والخطوط فقط وسجّل «نواقص مطلوبة: أنشئ MAP لـ …».",
          sortOrder: 21,
        },
        {
          type: "BG",
          name: "غرفة الحرب الليلية",
          role: "المسرح الثابت للقرارات",
          nameEn: "Night war-room",
          imagePath: "/seed/bg-warroom.png",
          description: "نفس المكتب، نفس المصباح النحاسي، نفس الخريطة على الجدار — في كل الحلقات.",
          prompt: "يُرفق كخلفية مسرحية ثابتة لمشاهد القرارات والاجتماعات الليلية.",
          sortOrder: 30,
        },
        {
          type: "PROP",
          name: "برميل نفط",
          role: "توقيع بصري — الذهب الأسود",
          nameEn: "Oil barrel prop",
          imagePath: "/seed/prop-barrel.png",
          description: "نفس البرميل الصدئ في كل الفيديوهات — يصبح توقيعًا يعرفه متابعوك قبل أي نص.",
          prompt: "يُرفق كمرجع ثابت في أي مشهد يذكر النفط أو الثروة.",
          sortOrder: 40,
        },
        {
          type: "PROP",
          name: "دبابة الحرب",
          role: "توقيع بصري — الآلة العسكرية",
          nameEn: "War tank prop",
          description: "مرجع ثابت للآليات العسكرية. أنشئ صورته المرجعية من نفس نمط STYLE قبل أول حلقة تستخدمه.",
          prompt: "لا يُستخدم قبل رفع الصورة المرجعية — بلا صورة لا توليد.",
          sortOrder: 41,
        },
      ])
      .returning();

    const ep = await db
      .insert(episodes)
      .values({
        code: "EP01",
        title: "الحرب العالمية الأولى — الجزء الأول",
        narrative: WWI_NARRATIVE,
        notes: WWI_NOTES,
        status: "production",
        favorite: true,
      })
      .returning();

    const result = runBreakdown({
      narrative: WWI_NARRATIVE,
      notes: WWI_NOTES,
      assets: inserted,
      styleLock: SEED_STYLE_LOCK,
      negative: NEGATIVE_DEFAULT,
    });

    await db.insert(scenes).values(
      result.scenes.map((s, i) => ({
        episodeId: ep[0].id,
        num: s.num,
        title: s.title,
        narration: s.narration,
        expression: s.expression,
        expressionEn: s.expressionEn,
        camera: s.camera,
        lighting: s.lighting,
        locationText: s.locationText,
        promptRef: s.promptRef,
        promptScene: s.promptScene,
        promptExpression: s.promptExpression,
        promptStyle: s.promptStyle,
        promptNegative: s.promptNegative,
        characterIds: s.characterIds,
        mapId: s.mapId,
        bgId: s.bgId,
        propIds: s.propIds,
        missing: s.missing,
        isMap: s.isMap,
        sortOrder: s.num,
        status: i === 0 ? "approved" : i === 1 ? "ready" : "draft",
        imagePath: i === 0 ? "/seed/slide-sc01.png" : null,
      }))
    );

    seeded = true;
  } catch (e) {
    // الجداول غير موجودة بعد (قبل drizzle-kit push) — نتجاهل ونحاول لاحقًا
    console.error("seed skipped:", e);
  }
}

export function resetSeedFlag() {
  seeded = false;
}
