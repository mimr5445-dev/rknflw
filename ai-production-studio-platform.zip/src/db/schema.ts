import {
  pgTable,
  text,
  uuid,
  boolean,
  integer,
  timestamp,
  jsonb,
  index,
} from "drizzle-orm/pg-core";

/**
 * استوديو الهوية الثابتة — مخطط قاعدة البيانات
 * assets   = المصادر المقدسة (RULE / STYLE / CHAR / CHAR-EXP / MAP / MAP-STYLE / BG / PROP)
 * episodes = الحلقات (وحدة الإنتاج: سرد → مشاهد → شرائح)
 * scenes   = مشاهد الاستوري بورد مع برومبتات التوليد
 */

export const assets = pgTable(
  "assets",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    type: text("type").notNull(), // RULE | STYLE | CHAR | CHAR-EXP | MAP | MAP-STYLE | BG | PROP
    name: text("name").notNull(),
    role: text("role"), // الوظيفة / اللقب (تُظهر في بطاقة الهوية)
    nameEn: text("name_en"), // الاسم الإنجليزي للبرومبتات
    description: text("description"),
    prompt: text("prompt"), // تعليمات استخدام/توليد هذا المصدر
    styleLock: text("style_lock"), // سطر النمط المقدس (لنوع STYLE)
    era: text("era"), // الفترة (لخرائط MAP)
    imagePath: text("image_path"),
    favorite: boolean("favorite").notNull().default(false),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("assets_type_idx").on(t.type), index("assets_fav_idx").on(t.favorite)]
);

export const episodes = pgTable(
  "episodes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: text("code").notNull(), // EP01
    title: text("title").notNull(),
    narrative: text("narrative").notNull().default(""), // السرد الخام
    notes: text("notes").notNull().default(""), // الملاحظات الإخراجية
    status: text("status").notNull().default("prep"), // prep | production | edit | published
    favorite: boolean("favorite").notNull().default(false),
    gates: jsonb("gates").notNull().default({}), // تأكيدات بوابات الجودة اليدوية
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("episodes_status_idx").on(t.status)]
);

export const scenes = pgTable(
  "scenes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    episodeId: uuid("episode_id")
      .notNull()
      .references(() => episodes.id, { onDelete: "cascade" }),
    num: integer("num").notNull(),
    title: text("title").notNull().default(""),
    narration: text("narration").notNull().default(""),
    expression: text("expression").notNull().default("محايد"),
    expressionEn: text("expression_en").notNull().default(""),
    camera: text("camera").notNull().default("لقطة متوسطة — مستوى النظر"),
    lighting: text("lighting").notNull().default("تيل محايد سينمائي"),
    locationText: text("location_text"),
    promptRef: text("prompt_ref").notNull().default(""),
    promptScene: text("prompt_scene").notNull().default(""),
    promptExpression: text("prompt_expression").notNull().default(""),
    promptStyle: text("prompt_style").notNull().default(""),
    promptNegative: text("prompt_negative").notNull().default(""),
    characterIds: jsonb("character_ids").notNull().default([]),
    mapId: uuid("map_id"),
    bgId: uuid("bg_id"),
    propIds: jsonb("prop_ids").notNull().default([]),
    missing: jsonb("missing").notNull().default([]), // نواقص مطلوبة للمشهد
    isMap: boolean("is_map").notNull().default(false),
    status: text("status").notNull().default("draft"), // draft | ready | generated | approved
    imagePath: text("image_path"), // الشريحة المولّدة
    notes: text("notes").notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("scenes_episode_idx").on(t.episodeId), index("scenes_status_idx").on(t.status)]
);

export type Asset = typeof assets.$inferSelect;
export type NewAsset = typeof assets.$inferInsert;
export type Episode = typeof episodes.$inferSelect;
export type NewEpisode = typeof episodes.$inferInsert;
export type Scene = typeof scenes.$inferSelect;
export type NewScene = typeof scenes.$inferInsert;
