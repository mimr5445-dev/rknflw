"use client";

import { useMemo, useState } from "react";
import { CopyButton } from "@/components/ui";
import { displayName } from "@/lib/studio";
import type { Asset } from "@/db/schema";
import { Download, NotebookPen, Send, Sparkles } from "lucide-react";

/** مولّد حزمة تعليمات NotebookLM — يقرأ المكتبة الحية ويبني النص الجاهز للصق */
export function GuideClient({ assets, ruleText, styleLock }: { assets: Asset[]; ruleText: string; styleLock: string }) {
  const [episodeTitle, setEpisodeTitle] = useState("الحرب العالمية الأولى — الجزء الأول");

  const manifest = useMemo(() => {
    const order: Record<string, number> = { RULE: 0, STYLE: 1, CHAR: 2, "CHAR-EXP": 3, MAP: 4, "MAP-STYLE": 5, BG: 6, PROP: 7 };
    return [...assets]
      .sort((a, b) => (order[a.type] ?? 9) - (order[b.type] ?? 9) || a.sortOrder - b.sortOrder)
      .map((a) => `- ${displayName(a)}${a.imagePath ? " (صورة مرفوعة)" : " (نصي)"}`)
      .join("\n");
  }, [assets]);

  const wakeCommand = "الوضع: إنتاج حلقة";

  const episodeTemplate = `[EPXX — ${episodeTitle}]
نفّذ الاستوري بورد حسب RULE — دستور الاستوديو.
السرد:
[الصق النص هنا]
ملاحظات إخراجية: المشاهد التي فيها خريطة استخدم مصادر MAP المعتمدة فقط. حدّد ذروة الانفعال لكل مشهد (صدمة/انفجار/بكاء…).`;

  const fullPack = `حزمة تشغيل «استوديو الهوية الثابتة» على NotebookLM
═══════════════════════════════════════════════════

الخطوة 1 — أنشئ دفترًا جديدًا باسم: «الاستوديو المركزي — الهوية المقدسة» (لا يتغير أبدًا).

الخطوة 2 — ارفع المصادر بالترتيب وبأسمائها الحرفية:
${manifest}

الخطوة 3 — ألصق النص التالي كأول مصدر باسم «RULE — دستور الاستوديو»:
───────────────────────────────────
${ruleText}
───────────────────────────────────

الخطوة 4 — افتح محادثة جديدة لكل حلقة (لا تخلط ذاكرة القصص أبدًا) واكتب:
«${wakeCommand}»
سيجيب: «الاستوديو جاهز — أرسل السرد» ثم انتظر.

الخطوة 5 — أرسل السرد بهذا القالب:
───────────────────────────────────
${episodeTemplate}
───────────────────────────────────

سطر STYLE LOCK (يُنسخ حرفيًا في كل برومبت):
${styleLock || "—"}
`;

  function downloadTxt() {
    const blob = new Blob([fullPack], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "NOTEBOOKLM-INSTRUCTIONS.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="glass rounded-3xl p-6 lg:p-8">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="sec-num mb-2">NOTEBOOKLM LAUNCHER</p>
          <h2 className="display flex items-center gap-2 text-2xl text-white">
            <NotebookPen className="size-6 text-gold-400" /> مولّد تعليمات NotebookLM
          </h2>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-zinc-400">
            يقرأ مكتبتك الحية الآن ويبني حزمة التشغيل كاملة: أمر الاستيقاظ، الدستور، قائمة المصادر بأسمائها الحرفية، وقالب إرسال السرد.
          </p>
        </div>
        <div className="flex gap-2">
          <CopyButton text={fullPack} label="نسخ الحزمة كاملة" />
          <button className="btn btn-teal" onClick={downloadTxt}>
            <Download className="size-4" /> تنزيل TXT
          </button>
        </div>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[13px] font-bold text-white">1 · أمر الاستيقاظ</p>
            <CopyButton small text={wakeCommand} />
          </div>
          <p className="rounded-xl bg-gold-500/10 p-3 text-center font-bold text-gold-400">{wakeCommand}</p>
          <p className="mt-2 text-[11px] leading-5 text-zinc-500">محادثة جديدة لكل حلقة — الدفتر واحد والذاكرة منعزلة.</p>
        </div>

        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[13px] font-bold text-white">2 · الدستور (مصدر RULE)</p>
            <CopyButton small text={ruleText} />
          </div>
          <p className="line-clamp-4 text-[11px] leading-6 text-zinc-500">{ruleText}</p>
        </div>

        <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-4">
          <div className="mb-2 flex items-center justify-between">
            <p className="text-[13px] font-bold text-white">3 · قالب إرسال السرد</p>
            <CopyButton small text={episodeTemplate} />
          </div>
          <input
            className="input !py-2 !text-xs"
            value={episodeTitle}
            onChange={(e) => setEpisodeTitle(e.target.value)}
            placeholder="عنوان الحلقة داخل القالب"
          />
          <p className="mt-2 flex items-center gap-1 text-[11px] text-zinc-500">
            <Send className="size-3" /> عدّل العنوان وسيتحدث القالب فورًا.
          </p>
        </div>
      </div>

      <div className="mt-4 rounded-2xl border border-white/[0.08] bg-black/30 p-4">
        <p className="mb-2 flex items-center gap-2 text-[13px] font-bold text-white">
          <Sparkles className="size-4 text-gold-400" /> معاينة الحزمة الكاملة ({assets.length} مصدر)
        </p>
        <pre className="max-h-96 overflow-y-auto whitespace-pre-wrap font-body text-[12px] leading-7 text-zinc-300">{fullPack}</pre>
      </div>
    </div>
  );
}
