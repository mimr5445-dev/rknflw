"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import type { Asset } from "@/db/schema";
import { EXPRESSIONS, NEGATIVE_DEFAULT, displayName, type SourceTypeKey } from "@/lib/studio";
import { AssetFormModal, emptyDraft, type AssetDraft } from "@/components/asset-form";
import { CopyButton } from "@/components/ui";
import { BookMarked, FlaskConical, Map, Palette, ScanFace, SmilePlus } from "lucide-react";

type Tab = "char" | "exp" | "map" | "style";

const TABS: { key: Tab; label: string; icon: typeof ScanFace }[] = [
  { key: "char", label: "بطاقة هوية شخصية", icon: ScanFace },
  { key: "exp", label: "ورقة التعابير", icon: SmilePlus },
  { key: "map", label: "أطلس الخرائط", icon: Map },
  { key: "style", label: "STYLE LOCK", icon: Palette },
];

export function LabClient({
  assets,
  prefillType,
  prefillName,
}: {
  assets: Asset[];
  prefillType: string | null;
  prefillName: string | null;
}) {
  const router = useRouter();
  const chars = useMemo(() => assets.filter((a) => a.type === "CHAR"), [assets]);
  const styles = useMemo(() => assets.filter((a) => a.type === "STYLE"), [assets]);
  const styleLock = styles.find((s) => s.styleLock)?.styleLock || "";

  const [tab, setTab] = useState<Tab>(prefillType === "MAP" ? "map" : "char");
  const [draft, setDraft] = useState<AssetDraft | null>(null);

  // بطاقة هوية
  const [cName, setCName] = useState(prefillName ?? "");
  const [cNameEn, setCNameEn] = useState("");
  const [cRole, setCRole] = useState("");
  const [cFeatures, setCFeatures] = useState("");

  // ورقة تعابير
  const [expCharId, setExpCharId] = useState(chars[0]?.id ?? "");
  const expChar = chars.find((c) => c.id === expCharId) ?? chars[0];

  // خريطة
  const [mRegion, setMRegion] = useState(prefillType === "MAP" ? prefillName ?? "" : "");
  const [mEra, setMEra] = useState("");
  const [mNotes, setMNotes] = useState("");

  // STYLE LOCK
  const [styleLockEdit, setStyleLockEdit] = useState(styleLock);
  const [styleAssetId] = useState(styles.find((s) => s.styleLock)?.id ?? "");
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const charPrompt = `Create the official reference portrait of ${cNameEn || "the character"}${cRole ? ` (${cRole})` : ""}.
Identity locks (never change across the whole series): ${cFeatures || "describe hair, outfit, signature details"}.
Head-and-shoulders, facing camera, cinematic flat lighting, 16:9 frame.
[STYLE LOCK]: ${styleLockEdit || styleLock || "(ضع سطر النمط هنا)"}
[NEGATIVE]: ${NEGATIVE_DEFAULT}`;

  const expPrompt = `Using the attached official reference image of "${expChar ? displayName(expChar) : "CHAR — …"}", create a single 2x3 expression sheet of ${expChar?.nameEn || expChar?.name || "the character"}:
neutral / anger / explosion / joy / crying / shock.
Same identity, same outfit, identical face geometry — ONLY eyes, eyebrows and mouth change (rubber-face principle).
Equal grid cells, labels off, 16:9 sheet.
[STYLE LOCK]: ${styleLockEdit || styleLock || "(ضع سطر النمط هنا)"}
[NEGATIVE]: ${NEGATIVE_DEFAULT}`;

  const mapPrompt = `Create the locked base atlas map of ${mRegion || "the region"}${mEra ? ` in ${mEra}` : ""}.
Apply the official cartography style (MAP-STYLE): same palette, border line weight, label font and lighting.
Clean accurate borders — this map will be edited later, never re-generated.
${mNotes ? `Extra notes: ${mNotes}.` : ""}
16:9 frame, matte paper background.
[STYLE LOCK]: ${styleLockEdit || styleLock || "(ضع سطر النمط هنا)"}
[NEGATIVE]: ${NEGATIVE_DEFAULT}`;

  async function saveStyleLock() {
    if (!styleAssetId) return;
    await fetch(`/api/assets/${styleAssetId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ styleLock: styleLockEdit }),
    });
    setSavedMsg("حُفظ سطر النمط في مصدر STYLE — سيُلصق حرفيًا في كل برومبت.");
    setTimeout(() => setSavedMsg(null), 2500);
    router.refresh();
  }

  function registerAsAsset() {
    if (tab === "char") {
      const d0 = emptyDraft("CHAR");
      setDraft({ ...d0, name: cName, nameEn: cNameEn, role: cRole, description: cFeatures, prompt: "أرفق هذه الصورة نفسها مع كل مشهد يذكر الشخصية — الهوية ثابتة حرفيًا." });
    } else if (tab === "exp") {
      const d0 = emptyDraft("CHAR-EXP");
      setDraft({ ...d0, name: `${expChar?.name ?? ""} — ورقة التعابير`, nameEn: `${expChar?.nameEn ?? ""} expression sheet`, role: "التعابير الستة المعتمدة", prompt: "استخدم الإطار المطابق لتعبير المشهد كمرجع مرفق — ورقة التعابير أقوى من الكلام." });
    } else if (tab === "map") {
      const d0 = emptyDraft("MAP");
      setDraft({ ...d0, name: mRegion, era: mEra, description: mNotes, prompt: "الخريطة تُعدَّل ولا تُولَّد: أرفق نفس الصورة وأضف الأسهم والأعلام فقط دون تغيير الحدود." });
    }
  }

  const activePrompt = tab === "char" ? charPrompt : tab === "exp" ? expPrompt : tab === "map" ? mapPrompt : "";

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="sec-num mb-2">CHARACTER & WORLD LAB</p>
          <h1 className="display text-3xl text-white">المختبر</h1>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-zinc-400">
            هنا تُولد عناصر الحقيبة من نفس السلالة: مرجع الشخصية، ورقة تعابيرها، وخرائط الأطلس — ببرومبتات جاهزة للنسخ مقفلة على نمط الاستوديو.
          </p>
        </div>
        <span className="chip !py-1.5 !px-3 text-gold-400 !border-gold-500/40 !bg-gold-500/10">
          <FlaskConical className="size-3.5" /> {chars.length} شخصية في الحقيبة
        </span>
      </div>

      {/* التبويبات */}
      <div className="glass flex flex-wrap gap-2 rounded-2xl p-2">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            onClick={() => setTab(key)}
            className={`btn flex-1 justify-center !text-[13px] ${tab === key ? "btn-gold" : "btn-ghost"}`}
          >
            <Icon className="size-4" /> {label}
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* المدخلات */}
        <div className="glass space-y-4 rounded-3xl p-6">
          {tab === "char" && (
            <>
              <h2 className="display flex items-center gap-2 text-lg text-white">
                <ScanFace className="size-5 text-gold-400" /> بطاقة هوية شخصية جديدة
              </h2>
              <p className="text-[13px] leading-6 text-zinc-400">
                الصورة المرجعية تُولَّد <b className="text-gold-400">مرة واحدة</b> وتصبح الوجه الرسمي الوحيد — ليعرفها متابعوك قبل أن تذكر اسمها.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">اسم الشخصية</label>
                  <input className="input" value={cName} onChange={(e) => setCName(e.target.value)} placeholder="ترامب" />
                </div>
                <div>
                  <label className="label">الاسم الإنجليزي</label>
                  <input className="input" dir="ltr" value={cNameEn} onChange={(e) => setCNameEn(e.target.value)} placeholder="Donald Trump" />
                </div>
              </div>
              <div>
                <label className="label">الوظيفة (بطاقة الهوية)</label>
                <input className="input" value={cRole} onChange={(e) => setCRole(e.target.value)} placeholder="رئيس الولايات المتحدة 2017–2021" />
              </div>
              <div>
                <label className="label">أقفال الهوية (ما لا يتغير أبدًا)</label>
                <textarea className="textarea" value={cFeatures} onChange={(e) => setCFeatures(e.target.value)} placeholder="شعر أشقر ممشط للخلف، بدلة كحلية، ربطة حمراء طويلة، دبوس علم…" />
              </div>
            </>
          )}

          {tab === "exp" && (
            <>
              <h2 className="display flex items-center gap-2 text-lg text-white">
                <SmilePlus className="size-5 text-gold-400" /> ورقة التعابير المعتمدة
              </h2>
              <p className="text-[13px] leading-6 text-zinc-400">
                ورقة التعابير <b className="text-gold-400">أقوى من الكلام</b>: عند المشهد، مرجع أداة التوليد هو الوجه المطلوب أصلًا.
              </p>
              <div>
                <label className="label">الشخصية</label>
                <select className="select" value={expCharId} onChange={(e) => setExpCharId(e.target.value)}>
                  {chars.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} — {c.role}
                    </option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-3 gap-2">
                {EXPRESSIONS.filter((x) => x.ar !== "سخرية" && x.ar !== "انزعاج").map((x) => (
                  <div key={x.ar} className="rounded-xl border border-white/10 bg-white/[0.03] p-2.5 text-center">
                    <p className="text-[13px] font-bold text-white">{x.ar}</p>
                    <p className="mt-0.5 text-[10px] text-zinc-500">{x.hint}</p>
                  </div>
                ))}
              </div>
              <p className="text-[11px] leading-5 text-zinc-500">
                العينان والحاجبان والفم فقط يتغيران — بقية الهندسة ثابتة حرفيًا.
              </p>
            </>
          )}

          {tab === "map" && (
            <>
              <h2 className="display flex items-center gap-2 text-lg text-white">
                <Map className="size-5 text-tealx-400" /> خريطة جديدة للأطلس
              </h2>
              <p className="text-[13px] leading-6 text-zinc-400">
                القاعدة الذهبية: <b className="text-tealx-400">الخريطة تُعدَّل ولا تُولَّد.</b> ولّدها مرة واحدة بشكل مثالي، وفي كل مشهد أرفقها وأضف الأحداث فوقها فقط.
              </p>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">المنطقة / القارة</label>
                  <input className="input" value={mRegion} onChange={(e) => setMRegion(e.target.value)} placeholder="أوروبا" />
                </div>
                <div>
                  <label className="label">الفترة الزمنية</label>
                  <input className="input" value={mEra} onChange={(e) => setMEra(e.target.value)} placeholder="1914" />
                </div>
              </div>
              <div>
                <label className="label">ملاحظات جغرافية</label>
                <textarea className="textarea" value={mNotes} onChange={(e) => setMNotes(e.target.value)} placeholder="حدود ما قبل الحرب، عواصم محددة، مسارات جبهات…" />
              </div>
            </>
          )}

          {tab === "style" && (
            <>
              <h2 className="display flex items-center gap-2 text-lg text-white">
                <Palette className="size-5 text-gold-400" /> سطر النمط المقدس
              </h2>
              <p className="text-[13px] leading-6 text-zinc-400">
                يُنسخ حرفيًا كلمة بكلمة في خانة [STYLE LOCK] في كل برومبت — ممنوع إعادة صياغته أو اختصاره أو ترجمته.
              </p>
              <div>
                <label className="label">STYLE LOCK (EN)</label>
                <textarea
                  className="textarea !min-h-32 font-mono-en text-xs leading-6"
                  dir="ltr"
                  value={styleLockEdit}
                  onChange={(e) => setStyleLockEdit(e.target.value)}
                />
              </div>
              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3" dir="ltr">
                <p className="font-mono-en text-[10px] tracking-widest text-hotpink-500">NEGATIVE LOCK</p>
                <p className="mt-1 font-mono-en text-[11px] leading-5 text-zinc-400">{NEGATIVE_DEFAULT}</p>
              </div>
              {styleAssetId ? (
                <button className="btn btn-gold w-full justify-center" onClick={saveStyleLock}>
                  <BookMarked className="size-4" /> حفظ في مصدر STYLE
                </button>
              ) : (
                <p className="text-sm text-zinc-500">لا يوجد مصدر STYLE بعد — أنشئه من المكتبة أولاً.</p>
              )}
              {savedMsg && <p className="text-sm text-emerald-400">{savedMsg}</p>}
            </>
          )}
        </div>

        {/* المخرجات */}
        {tab !== "style" ? (
          <div className="glass flex flex-col rounded-3xl p-6">
            <div className="mb-4 flex items-center justify-between">
              <h3 className="display text-base text-white">برومبت التوليد الجاهز</h3>
              <CopyButton text={activePrompt} label="نسخ البرومبت" />
            </div>
            <pre className="prompt-box flex-1">{activePrompt}</pre>
            <ol className="mt-4 list-decimal space-y-1.5 pe-5 text-[12px] leading-6 text-zinc-400">
              <li>انسخ البرومبت إلى أداة التوليد (Gemini / Midjourney / Leonardo).</li>
              <li>{tab === "exp" ? "أرفق صورة المرجع الرسمية للشخصية معه." : tab === "map" ? "أرفق صورة MAP-STYLE ليتبع عين اللون والخط." : "ولّد عدة نسخ واختر أوضحها ملامح."}</li>
              <li>سجّل الناتج في المكتبة المقدسة بالزر أدناه مع رفع الصورة.</li>
            </ol>
            <button className="btn btn-teal mt-5 w-full justify-center" onClick={registerAsAsset}>
              <BookMarked className="size-4" /> سجّلها في المكتبة المقدسة
            </button>
          </div>
        ) : (
          <div className="glass rounded-3xl p-6">
            <h3 className="display mb-4 text-base text-white">جدول الوجه المطاطي المعتمد</h3>
            <div className="space-y-2">
              {EXPRESSIONS.map((x) => (
                <div key={x.ar} className="flex items-center gap-3 rounded-xl border border-white/[0.07] bg-white/[0.02] p-3">
                  <span className="w-16 text-sm font-bold text-gold-400">{x.ar}</span>
                  <span className="text-[11px] text-zinc-500">{x.hint}</span>
                  <span className="ms-auto font-mono-en text-[10px] text-zinc-600" dir="ltr">
                    {x.en}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <AssetFormModal open={!!draft} draft={draft} onClose={() => setDraft(null)} onSaved={() => router.refresh()} onChange={setDraft} />
    </div>
  );
}
