"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { AnimatePresence, motion } from "framer-motion";
import type { Episode, Scene } from "@/db/schema";
import { assemblePrompt, pad2, sceneStatusMeta } from "@/lib/studio";
import { CopyButton } from "@/components/ui";
import {
  Camera,
  ChevronLeft,
  ChevronRight,
  Code2,
  Lightbulb,
  Map as MapIcon,
  MonitorX,
  Pause,
  Play,
  Smile,
  X,
} from "lucide-react";

const SLIDE_MS = 6500;

export function SlidesClient({ episode, scenes }: { episode: Episode; scenes: Scene[] }) {
  const [idx, setIdx] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);
  const scene = scenes[idx];

  const next = useCallback(() => setIdx((i) => Math.min(i + 1, scenes.length - 1)), [scenes.length]);
  const prev = useCallback(() => setIdx((i) => Math.max(i - 1, 0)), []);

  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, []);

  useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => {
      setIdx((i) => {
        if (i >= scenes.length - 1) {
          setPlaying(false);
          return i;
        }
        return i + 1;
      });
    }, SLIDE_MS);
    return () => clearInterval(t);
  }, [playing, scenes.length]);

  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "ArrowLeft") prev();
      if (e.key === "ArrowRight") next();
      if (e.key === " ") {
        e.preventDefault();
        setPlaying((p) => !p);
      }
    };
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [next, prev]);

  if (!scenes.length) {
    return (
      <div className="fixed inset-0 z-[90] grid place-items-center bg-ink-950">
        <div className="text-center">
          <MonitorX className="mx-auto mb-4 size-10 text-zinc-600" />
          <p className="display text-xl text-white">لا مشاهد في هذه الحلقة بعد</p>
          <Link href={`/production/${episode.id}`} className="btn btn-gold mt-5">
            عودة لغرفة الإخراج
          </Link>
        </div>
      </div>
    );
  }

  const meta = sceneStatusMeta(scene.status);

  return (
    <div className="fixed inset-0 z-[90] flex flex-col bg-ink-950">
      {/* تقدّم */}
      <div className="flex gap-1 p-4 pb-0" dir="ltr">
        {scenes.map((s, i) => (
          <button
            key={s.id}
            onClick={() => setIdx(i)}
            className="h-1 flex-1 overflow-hidden rounded-full bg-white/10"
            title={`SCENE ${pad2(s.num)}`}
          >
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: i < idx ? "100%" : i === idx ? "100%" : "0%",
                background: i === idx ? "#E9B44C" : "rgba(255,255,255,.35)",
              }}
            />
          </button>
        ))}
      </div>

      {/* المسرح */}
      <div className="relative flex-1 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={scene.id}
            initial={{ opacity: 0, scale: 1.04 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.98 }}
            transition={{ duration: 0.65, ease: [0.2, 0.9, 0.25, 1] }}
            className="absolute inset-0"
          >
            {scene.imagePath ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={scene.imagePath} alt={scene.title} className="size-full object-contain" />
            ) : (
              <div className="relative grid size-full place-items-center overflow-hidden bg-[radial-gradient(50rem_30rem_at_50%_40%,rgb(233_180_76/0.08),transparent)]">
                <span className="scene-giant select-none" dir="ltr">
                  {pad2(scene.num)}
                </span>
                <div className="absolute bottom-1/3 flex flex-col items-center gap-2">
                  <span className="chip !border-gold-500/40 !bg-gold-500/10 !text-gold-400 !px-4 !py-1.5 !text-sm">
                    <Smile className="size-4" /> التعبير: {scene.expression}
                  </span>
                  <span className="text-xs text-zinc-500">لم تُولَّد الشريحة بعد — ولّدها وارفعها من غرفة الإخراج</span>
                </div>
              </div>
            )}
            <div className="pointer-events-none absolute inset-x-0 bottom-0 h-56 bg-gradient-to-t from-ink-950 via-ink-950/70 to-transparent" />
          </motion.div>
        </AnimatePresence>

        {/* معلومات المشهد */}
        <div className="absolute inset-x-0 bottom-0 p-6 sm:p-10">
          <div className="mx-auto max-w-5xl">
            <motion.div
              key={`info-${scene.id}`}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15, duration: 0.5 }}
              className="flex flex-wrap items-end justify-between gap-4"
            >
              <div className="min-w-0">
                <p className="font-mono-en text-xs font-bold tracking-[0.3em] text-gold-500" dir="ltr">
                  SCENE {pad2(scene.num)} {scene.isMap && "— MAP SHOT"}
                </p>
                <h2 className="display mt-1 text-2xl text-white sm:text-3xl">{scene.title}</h2>
                <p className="mt-2 max-w-3xl text-sm leading-8 text-zinc-300">{scene.narration}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="chip"><Smile className="size-3 text-gold-400" /> {scene.expression}</span>
                  <span className="chip"><Camera className="size-3 text-sky-400" /> {scene.camera}</span>
                  <span className="chip"><Lightbulb className="size-3 text-violet-400" /> {scene.lighting}</span>
                  {scene.isMap && <span className="chip"><MapIcon className="size-3 text-tealx-400" /> خريطة</span>}
                  <span className="chip" style={{ color: meta.color, borderColor: `${meta.color}55`, background: `${meta.color}14` }}>{meta.label}</span>
                </div>
              </div>
              <span className="font-mono-en text-6xl font-extrabold text-white/10" dir="ltr">
                {pad2(scene.num)}
              </span>
            </motion.div>
          </div>
        </div>
      </div>

      {/* لوحة التحكم */}
      <div className="flex items-center justify-between gap-3 border-t border-white/[0.07] bg-ink-900/80 px-4 py-3 backdrop-blur sm:px-8">
        <div className="flex items-center gap-2">
          <Link href={`/production/${episode.id}`} className="btn btn-ghost !px-3">
            <X className="size-4" /> خروج
          </Link>
          <span className="hidden text-xs font-bold text-zinc-500 sm:inline">
            {episode.code} — {episode.title}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button className="btn btn-ghost !px-3" onClick={prev} disabled={idx === 0}>
            <ChevronRight className="size-5" />
          </button>
          <button className="btn btn-gold !px-5" onClick={() => setPlaying((p) => !p)}>
            {playing ? <Pause className="size-4" /> : <Play className="size-4" />}
            {playing ? "إيقاف" : "تشغيل"}
          </button>
          <button className="btn btn-ghost !px-3" onClick={next} disabled={idx === scenes.length - 1}>
            <ChevronLeft className="size-5" />
          </button>
        </div>
        <div className="flex items-center gap-3">
          <span className="font-mono-en text-xs font-bold text-zinc-400" dir="ltr">
            {pad2(idx + 1)} / {pad2(scenes.length)}
          </span>
          <button className="btn btn-ghost !px-3 !text-[11px]" onClick={() => setShowPrompt((v) => !v)}>
            <Code2 className="size-4" /> البرومبت
          </button>
        </div>
      </div>

      {/* درج البرومبت */}
      <AnimatePresence>
        {showPrompt && (
          <motion.div
            initial={{ y: "100%" }}
            animate={{ y: 0 }}
            exit={{ y: "100%" }}
            transition={{ type: "spring", damping: 30, stiffness: 300 }}
            className="absolute inset-x-0 bottom-16 z-10 mx-auto max-h-[60vh] w-[min(92vw,52rem)] overflow-y-auto rounded-2xl border border-white/10 bg-ink-900/97 p-5 shadow-2xl backdrop-blur-xl"
          >
            <div className="mb-3 flex items-center justify-between">
              <p className="text-sm font-bold text-white">برومبت المشهد الحالي</p>
              <CopyButton small text={assemblePrompt(scene)} label="نسخ" />
            </div>
            <pre className="prompt-box">{assemblePrompt(scene)}</pre>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
