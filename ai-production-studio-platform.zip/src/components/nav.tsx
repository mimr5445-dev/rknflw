"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Fingerprint, FlaskConical, LayoutDashboard, LibraryBig, ScrollText, Workflow } from "lucide-react";

const LINKS = [
  { href: "/", label: "الرئيسية", icon: LayoutDashboard },
  { href: "/library", label: "المكتبة المقدسة", icon: LibraryBig },
  { href: "/lab", label: "المختبر", icon: FlaskConical },
  { href: "/production", label: "خط الإنتاج", icon: Workflow },
  { href: "/guide", label: "الدليل والتعليمات", icon: ScrollText },
];

export function SiteNav() {
  const pathname = usePathname();
  return (
    <header className="sticky top-0 z-50 border-b border-white/[0.07] bg-ink-950/80 backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-[1400px] items-center gap-3 px-4 py-3 sm:px-6 lg:px-10">
        <Link href="/" className="group flex items-center gap-3">
          <span className="grid size-10 place-items-center rounded-xl bg-gradient-to-br from-gold-400 to-[#b07e1f] text-ink-950 shadow-[0_6px_20px_-6px_rgb(233_180_76/0.6)] transition-transform group-hover:scale-105">
            <Fingerprint className="size-5" strokeWidth={2.2} />
          </span>
          <span className="leading-tight">
            <span className="display block text-[15px] text-white">استوديو الهوية الثابتة</span>
            <span className="block text-[10px] font-medium tracking-wider text-zinc-500">
              FIXED IDENTITY STUDIO
            </span>
          </span>
        </Link>

        <nav className="ms-auto flex items-center gap-1 overflow-x-auto">
          {LINKS.map(({ href, label, icon: Icon }) => {
            const active = href === "/" ? pathname === "/" : pathname.startsWith(href);
            return (
              <Link
                key={href}
                href={href}
                className={`flex items-center gap-1.5 whitespace-nowrap rounded-xl px-3 py-2 text-[13px] font-bold transition-all ${
                  active
                    ? "bg-gold-500/15 text-gold-400 shadow-[inset_0_0_0_1px_rgb(233_180_76/0.25)]"
                    : "text-zinc-400 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon className="size-4" />
                <span className="hidden md:inline">{label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
