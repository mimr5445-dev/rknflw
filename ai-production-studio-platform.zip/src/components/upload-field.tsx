"use client";

import { useRef, useState } from "react";
import { ImageUp, Loader2, Trash2 } from "lucide-react";

/** حقل رفع صورة مرجعية مع معاينة فورية */
export function UploadField({
  value,
  onChange,
  hint,
}: {
  value: string | null;
  onChange: (path: string | null) => void;
  hint?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function handleFile(file: File | undefined) {
    if (!file) return;
    setErr(null);
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "فشل الرفع");
      onChange(data.path);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "فشل الرفع");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div>
      {value ? (
        <div className="group relative overflow-hidden rounded-xl border border-white/10">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={value} alt="الصورة المرجعية" className="h-44 w-full object-cover" />
          <div className="absolute inset-0 flex items-center justify-center gap-2 bg-black/60 opacity-0 transition-opacity group-hover:opacity-100">
            <button type="button" className="btn btn-ghost !text-xs" onClick={() => inputRef.current?.click()}>
              <ImageUp className="size-4" /> استبدال
            </button>
            <button type="button" className="btn btn-danger !text-xs" onClick={() => onChange(null)}>
              <Trash2 className="size-4" /> إزالة
            </button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            handleFile(e.dataTransfer.files?.[0]);
          }}
          className="flex h-28 w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.03] text-zinc-400 transition-colors hover:border-gold-500/50 hover:text-gold-400"
        >
          {busy ? <Loader2 className="size-5 animate-spin" /> : <ImageUp className="size-5" />}
          <span className="text-xs font-bold">{busy ? "جارٍ الرفع…" : "اسحب صورة أو انقر للرفع"}</span>
          {hint && <span className="text-[10px] text-zinc-600">{hint}</span>}
        </button>
      )}
      {err && <p className="mt-1 text-xs text-hotpink-500">{err}</p>}
      <input
        ref={inputRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/gif,image/svg+xml"
        className="hidden"
        onChange={(e) => handleFile(e.target.files?.[0])}
      />
    </div>
  );
}
