"use client";

import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import type { Asset } from "@/db/schema";
import { SOURCE_TYPES, displayName, typeColor } from "@/lib/studio";
import { AssetFormModal, draftFromAsset, emptyDraft, type AssetDraft } from "@/components/asset-form";
import { CopyButton, EmptyState, FavToggle, TypeChip } from "@/components/ui";
import {
  FileArchive,
  FileText,
  LibraryBig,
  Pencil,
  Plus,
  Search,
  Star,
  Trash2,
} from "lucide-react";

export function LibraryClient({ initialAssets }: { initialAssets: Asset[] }) {
  const router = useRouter();
  const [items, setItems] = useState(initialAssets);
  const [filter, setFilter] = useState("ALL");
  const [q, setQ] = useState("");
  const [favOnly, setFavOnly] = useState(false);
  const [draft, setDraft] = useState<AssetDraft | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<Asset | null>(null);
  const [busy, setBusy] = useState(false);

  const filtered = useMemo(
    () =>
      items.filter((a) => {
        if (filter !== "ALL" && a.type !== filter) return false;
        if (favOnly && !a.favorite) return false;
        if (q) {
          const hay = `${a.name} ${a.role ?? ""} ${a.description ?? ""} ${a.nameEn ?? ""}`;
          if (!hay.includes(q)) return false;
        }
        return true;
      }),
    [items, filter, q, favOnly]
  );

  const countOf = (t: string) => items.filter((a) => a.type === t).length;

  async function refresh() {
    const res = await fetch("/api/assets");
    setItems(await res.json());
    router.refresh();
  }

  async function toggleFav(a: Asset) {
    setItems((p) => p.map((x) => (x.id === a.id ? { ...x, favorite: !x.favorite } : x)));
    await fetch(`/api/assets/${a.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ favorite: !a.favorite }),
    });
  }

  async function doDelete() {
    if (!confirmDelete) return;
    setBusy(true);
    await fetch(`/api/assets/${confirmDelete.id}`, { method: "DELETE" });
    setBusy(false);
    setConfirmDelete(null);
    refresh();
  }

  return (
    <div className="space-y-6">
      {/* رأس الصفحة */}
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="sec-num mb-2">SACRED LIBRARY</p>
          <h1 className="display text-3xl text-white">المكتبة المقدسة</h1>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-zinc-400">
            حقيبة الممثلين والأطلس والدستور — كل مصدر هنا يُقرأ في NotebookLM باسمه الرسمي، ويُصدَّر مع صورته وتعليماته.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <a href="/api/export/library?format=zip" className="btn btn-teal">
            <FileArchive className="size-4" /> حزمة الهوية ZIP
          </a>
          <a href="/api/export/library?format=md" className="btn btn-ghost">
            <FileText className="size-4" /> نص Markdown
          </a>
          <button className="btn btn-gold" onClick={() => setDraft(emptyDraft("CHAR"))}>
            <Plus className="size-4" /> مصدر جديد
          </button>
        </div>
      </div>

      {/* أدوات التصفية */}
      <div className="glass flex flex-wrap items-center gap-3 rounded-2xl p-3">
        <div className="relative min-w-52 flex-1">
          <Search className="absolute end-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500" />
          <input
            className="input !pe-9"
            placeholder="ابحث باسم الشخصية أو الوظيفة أو الوصف…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            onClick={() => setFilter("ALL")}
            className={`chip transition-all ${filter === "ALL" ? "!border-gold-500/60 !bg-gold-500/15 !text-gold-400" : ""}`}
          >
            الكل ({items.length})
          </button>
          {SOURCE_TYPES.map((t) => (
            <button
              key={t.key}
              onClick={() => setFilter(t.key)}
              className="chip transition-all"
              style={
                filter === t.key
                  ? { color: t.color, borderColor: `${t.color}88`, background: `${t.color}1f` }
                  : {}
              }
              dir="ltr"
            >
              {t.key} ({countOf(t.key)})
            </button>
          ))}
          <button
            onClick={() => setFavOnly((v) => !v)}
            className={`chip transition-all ${favOnly ? "!border-gold-500/60 !bg-gold-500/15 !text-gold-400" : ""}`}
          >
            <Star className={`size-3 ${favOnly ? "fill-gold-400" : ""}`} /> المقدس
          </button>
        </div>
      </div>

      {/* الشبكة */}
      {filtered.length ? (
        <motion.div layout className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          <AnimatePresence>
            {filtered.map((a) => (
              <motion.article
                key={a.id}
                layout
                initial={{ opacity: 0, scale: 0.96 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.94 }}
                className="glass glass-hover group relative flex flex-col overflow-hidden rounded-3xl"
              >
                {/* الصورة */}
                <div className="relative h-44 overflow-hidden">
                  {a.imagePath ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={a.imagePath} alt={a.name} className="size-full object-cover transition-transform duration-500 group-hover:scale-105" />
                  ) : (
                    <div className="grid size-full place-items-center" style={{ background: `linear-gradient(150deg, ${typeColor(a.type)}1e, transparent)` }}>
                      <span className="font-mono-en text-xl font-extrabold tracking-[0.3em] opacity-40" style={{ color: typeColor(a.type) }} dir="ltr">
                        {a.type}
                      </span>
                    </div>
                  )}
                  <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-ink-950 to-transparent" />
                  <div className="absolute right-3 top-3 flex gap-2 opacity-0 transition-opacity group-hover:opacity-100">
                    <button
                      className="grid size-8 place-items-center rounded-lg border border-white/10 bg-black/60 text-zinc-300 backdrop-blur hover:text-white"
                      onClick={() => setDraft(draftFromAsset(a))}
                      title="تعديل"
                    >
                      <Pencil className="size-3.5" />
                    </button>
                    <button
                      className="grid size-8 place-items-center rounded-lg border border-white/10 bg-black/60 text-zinc-300 backdrop-blur hover:text-hotpink-500"
                      onClick={() => setConfirmDelete(a)}
                      title="حذف"
                    >
                      <Trash2 className="size-3.5" />
                    </button>
                  </div>
                  <div className="absolute left-3 top-3">
                    <FavToggle on={a.favorite} onToggle={() => toggleFav(a)} />
                  </div>
                  <div className="absolute bottom-3 right-3">
                    <TypeChip type={a.type} />
                  </div>
                </div>

                {/* المحتوى */}
                <div className="flex flex-1 flex-col gap-2 p-4">
                  <div>
                    <h3 className="display text-[15px] leading-6 text-white">{a.name}</h3>
                    {a.role && <p className="mt-0.5 text-[11px] font-medium text-zinc-400">{a.role}</p>}
                    {a.era && <p className="mt-0.5 font-mono-en text-[11px] text-tealx-400" dir="ltr">{a.era}</p>}
                  </div>
                  {a.description && (
                    <p className="line-clamp-2 text-[12px] leading-6 text-zinc-500">{a.description}</p>
                  )}
                  <div className="mt-auto flex items-center justify-between gap-2 border-t border-white/[0.06] pt-3">
                    <code className="min-w-0 truncate font-mono-en text-[10px] text-zinc-500" dir="ltr" title={displayName(a)}>
                      {displayName(a)}
                    </code>
                    <CopyButton small text={displayName(a)} label="الاسم" />
                  </div>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>
      ) : (
        <EmptyState
          icon={<LibraryBig className="size-7" />}
          title="لا توجد مصادر مطابقة"
          desc="جرّب تغيير الفلتر أو أضف أول مصدر للحقيبة المقدسة — تذكّر: لا وجه ولا حدود من الخيال."
          action={
            <button className="btn btn-gold" onClick={() => setDraft(emptyDraft("CHAR"))}>
              <Plus className="size-4" /> إضافة مصدر
            </button>
          }
        />
      )}

      {/* نماذج */}
      <AssetFormModal open={!!draft} draft={draft} onClose={() => setDraft(null)} onSaved={refresh} onChange={setDraft} />

      {confirmDelete && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setConfirmDelete(null)}>
          <div className="glass w-full max-w-sm rounded-3xl bg-ink-900/95 p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="display text-lg text-white">حذف «{confirmDelete.name}»؟</h3>
            <p className="mt-2 text-sm leading-7 text-zinc-400">
              سيُحذف هذا المصدر نهائيًا من الحقيبة. المشاهد القديمة ستفقد استشهادها به — هل أنت متأكد؟
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button className="btn btn-ghost" onClick={() => setConfirmDelete(null)}>
                تراجع
              </button>
              <button className="btn btn-danger" onClick={doDelete} disabled={busy}>
                <Trash2 className="size-4" /> حذف نهائي
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
