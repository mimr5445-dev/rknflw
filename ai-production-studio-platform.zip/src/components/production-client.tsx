"use client";

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import type { Episode } from "@/db/schema";
import { EPISODE_STATUSES, episodeStatusMeta } from "@/lib/studio";
import { EmptyState, FavToggle, Modal } from "@/components/ui";
import { Clapperboard, FolderOpen, Plus, Trash2 } from "lucide-react";

export interface EpisodeWithCounts extends Episode {
  sceneCount: number;
  approvedCount: number;
  generatedCount: number;
}

export function ProductionClient({ initialEpisodes }: { initialEpisodes: EpisodeWithCounts[] }) {
  const router = useRouter();
  const [items, setItems] = useState(initialEpisodes);
  const [createOpen, setCreateOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [narrative, setNarrative] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState<EpisodeWithCounts | null>(null);

  async function refresh() {
    const res = await fetch("/api/episodes");
    setItems(await res.json());
    router.refresh();
  }

  async function create() {
    if (!title.trim()) return;
    setBusy(true);
    const res = await fetch("/api/episodes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, narrative, notes }),
    });
    const ep = await res.json();
    setBusy(false);
    router.push(`/production/${ep.id}`);
  }

  async function toggleFav(ep: EpisodeWithCounts) {
    setItems((p) => p.map((x) => (x.id === ep.id ? { ...x, favorite: !x.favorite } : x)));
    await fetch(`/api/episodes/${ep.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ favorite: !ep.favorite }),
    });
  }

  async function setStatus(ep: EpisodeWithCounts, status: string) {
    setItems((p) => p.map((x) => (x.id === ep.id ? { ...x, status } : x)));
    await fetch(`/api/episodes/${ep.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
  }

  async function doDelete() {
    if (!confirmDelete) return;
    setBusy(true);
    await fetch(`/api/episodes/${confirmDelete.id}`, { method: "DELETE" });
    setBusy(false);
    setConfirmDelete(null);
    refresh();
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="sec-num mb-2">PRODUCTION LINE — TV ARCHIVE</p>
          <h1 className="display text-3xl text-white">خط الإنتاج</h1>
          <p className="mt-2 max-w-2xl text-sm leading-7 text-zinc-400">
            لكل حلقة مجلد كأرشيف تلفزيوني: السرد، المشاهد المرقمة، بوابات الجودة، والتصدير. لو احتجت إعادة مشهد بعد سنة، ستعرف بالضبط أي مرجع استُخدم.
          </p>
        </div>
        <button className="btn btn-gold" onClick={() => setCreateOpen(true)}>
          <Plus className="size-4" /> حلقة جديدة
        </button>
      </div>

      {items.length ? (
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          <AnimatePresence>
            {items.map((ep) => {
              const meta = episodeStatusMeta(ep.status);
              const pct = ep.sceneCount ? Math.round((ep.approvedCount / ep.sceneCount) * 100) : 0;
              return (
                <motion.div
                  key={ep.id}
                  layout
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.96 }}
                  className="glass glass-hover group relative flex flex-col rounded-3xl p-5"
                >
                  <div className="mb-3 flex items-start justify-between">
                    <span className="font-mono-en text-2xl font-extrabold tracking-tight text-gold-500/90" dir="ltr">
                      {ep.code}
                    </span>
                    <div className="flex items-center gap-2">
                      <FavToggle on={ep.favorite} onToggle={() => toggleFav(ep)} />
                      <button
                        className="grid size-8 place-items-center rounded-lg border border-white/10 bg-white/5 text-zinc-500 opacity-0 transition-opacity hover:text-hotpink-500 group-hover:opacity-100"
                        onClick={() => setConfirmDelete(ep)}
                        title="حذف الحلقة"
                      >
                        <Trash2 className="size-4" />
                      </button>
                    </div>
                  </div>

                  <Link href={`/production/${ep.id}`} className="block flex-1">
                    <h3 className="display text-lg leading-7 text-white transition-colors group-hover:text-gold-400">
                      {ep.title}
                    </h3>
                    <p className="mt-2 line-clamp-2 text-[12px] leading-6 text-zinc-500">
                      {ep.narrative || "لا يوجد سرد بعد — أضفه داخل غرفة الإخراج."}
                    </p>
                  </Link>

                  <div className="mt-4 space-y-3 border-t border-white/[0.06] pt-4">
                    <div className="flex items-center justify-between text-[11px] text-zinc-400">
                      <span>
                        {ep.sceneCount} مشهد · {ep.approvedCount} معتمد
                      </span>
                      <span className="font-mono-en font-bold" dir="ltr" style={{ color: meta.color }}>
                        {pct}%
                      </span>
                    </div>
                    <div className="h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
                      <div
                        className="h-full rounded-full transition-all duration-700"
                        style={{ width: `${pct}%`, background: `linear-gradient(90deg, ${meta.color}, #4ADE80)` }}
                      />
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <select
                        className="select !w-auto !border-white/10 !bg-white/[0.04] !py-1.5 !text-[11px]"
                        value={ep.status}
                        onChange={(e) => setStatus(ep, e.target.value)}
                      >
                        {EPISODE_STATUSES.map((s) => (
                          <option key={s.key} value={s.key}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                      <Link href={`/production/${ep.id}`} className="btn btn-ghost !px-3 !py-1.5 !text-[11px]">
                        <FolderOpen className="size-3.5" /> غرفة الإخراج
                      </Link>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
        </div>
      ) : (
        <EmptyState
          icon={<Clapperboard className="size-7" />}
          title="لا حلقات بعد"
          desc="أنشئ أول حلقة: الصق السرد، ودع محرك التفكيك يبني المشاهد وبرومبتاتها مستدعيًا حقيبتك المقدسة حصرًا."
          action={
            <button className="btn btn-gold" onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" /> إنشاء أول حلقة
            </button>
          }
        />
      )}

      {/* إنشاء حلقة */}
      <Modal open={createOpen} onClose={() => setCreateOpen(false)} title="حلقة جديدة — ملف قصة" wide>
        <div className="space-y-4">
          <div>
            <label className="label">عنوان الحلقة *</label>
            <input
              className="input"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="الحرب العالمية الأولى — الجزء الأول"
            />
          </div>
          <div>
            <label className="label">السرد الخام</label>
            <textarea
              className="textarea !min-h-44"
              value={narrative}
              onChange={(e) => setNarrative(e.target.value)}
              placeholder="الصق نص القصة هنا… كل مشهد سيصبح: مكان واحد + حدث واحد + انفعال واحد سائد."
            />
          </div>
          <div>
            <label className="label">ملاحظات إخراجية</label>
            <textarea
              className="textarea !min-h-20"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مشهد الاغتيال: صدمة بمستوى انفجار — الخرائط من MAP أوروبا 1914 — المشهد الأخير: انهيار بكاء."
            />
          </div>
          <div className="flex justify-end gap-2">
            <button className="btn btn-ghost" onClick={() => setCreateOpen(false)}>
              إلغاء
            </button>
            <button className="btn btn-gold" onClick={create} disabled={busy || !title.trim()}>
              <Clapperboard className="size-4" /> فتح ملف الحلقة
            </button>
          </div>
        </div>
      </Modal>

      {/* حذف */}
      {confirmDelete && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setConfirmDelete(null)}>
          <div className="glass w-full max-w-sm rounded-3xl bg-ink-900/95 p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="display text-lg text-white">حذف {confirmDelete.code}؟</h3>
            <p className="mt-2 text-sm leading-7 text-zinc-400">ستُحذف الحلقة وكل مشاهدها نهائيًا من الأرشيف.</p>
            <div className="mt-5 flex justify-end gap-2">
              <button className="btn btn-ghost" onClick={() => setConfirmDelete(null)}>
                تراجع
              </button>
              <button className="btn btn-danger" onClick={doDelete} disabled={busy}>
                <Trash2 className="size-4" /> حذف نهائي
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
