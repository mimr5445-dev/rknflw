"use client";

import { useEffect, useState, type ReactNode } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Check, Copy, Loader2, Star, X } from "lucide-react";
import { typeColor, typeLabel } from "@/lib/studio";

/* ─── شارة نوع المصدر ─── */
export function TypeChip({ type, big }: { type: string; big?: boolean }) {
  const c = typeColor(type);
  return (
    <span
      className={`chip ${big ? "px-3 py-1 text-xs" : ""}`}
      style={{ color: c, borderColor: `${c}55`, background: `${c}14` }}
      dir="ltr"
    >
      <span className="size-1.5 rounded-full" style={{ background: c }} />
      {type} · <span className="opacity-80">{typeLabel(type)}</span>
    </span>
  );
}

/* ─── زر النسخ ─── */
export function CopyButton({ text, label = "نسخ", small }: { text: string; label?: string; small?: boolean }) {
  const [done, setDone] = useState(false);
  return (
    <button
      className={`btn ${small ? "!px-2.5 !py-1.5 !text-[11px]" : ""} btn-ghost`}
      onClick={async (e) => {
        e.stopPropagation();
        try {
          await navigator.clipboard.writeText(text);
          setDone(true);
          setTimeout(() => setDone(false), 1400);
        } catch {
          /* noop */
        }
      }}
    >
      {done ? <Check className="size-3.5 text-emerald-400" /> : <Copy className="size-3.5" />}
      {done ? "نُسخ" : label}
    </button>
  );
}

/* ─── نجمة المفضلة ─── */
export function FavToggle({ on, onToggle }: { on: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={(e) => {
        e.stopPropagation();
        onToggle();
      }}
      title={on ? "إزالة من المقدس" : "تمييز كمقدس"}
      className={`grid size-8 place-items-center rounded-lg border transition-all ${
        on
          ? "border-gold-500/50 bg-gold-500/15 text-gold-400"
          : "border-white/10 bg-white/5 text-zinc-500 hover:text-gold-400"
      }`}
    >
      <Star className={`size-4 ${on ? "fill-gold-400" : ""}`} />
    </button>
  );
}

/* ─── نافذة منبثقة ─── */
export function Modal({
  open,
  onClose,
  title,
  children,
  wide,
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  wide?: boolean;
}) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    if (open) window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [open, onClose]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] grid place-items-center overflow-y-auto bg-black/70 p-4 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ opacity: 0, y: 24, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 16, scale: 0.98 }}
            transition={{ type: "spring", damping: 26, stiffness: 300 }}
            className={`glass my-8 w-full rounded-3xl bg-ink-900/95 p-6 shadow-2xl ${wide ? "max-w-3xl" : "max-w-xl"}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-5 flex items-center justify-between">
              <h3 className="display text-lg text-white">{title}</h3>
              <button onClick={onClose} className="grid size-8 place-items-center rounded-lg bg-white/5 text-zinc-400 hover:text-white">
                <X className="size-4" />
              </button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

/* ─── حالة فارغة ─── */
export function EmptyState({ icon, title, desc, action }: { icon: ReactNode; title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="glass fade-in flex flex-col items-center gap-3 rounded-3xl border-dashed px-6 py-16 text-center">
      <div className="grid size-14 place-items-center rounded-2xl bg-white/5 text-gold-400">{icon}</div>
      <h3 className="display text-lg text-white">{title}</h3>
      {desc && <p className="max-w-md text-sm leading-7 text-zinc-400">{desc}</p>}
      {action}
    </div>
  );
}

/* ─── مؤشر تحميل ─── */
export function Spinner({ label }: { label?: string }) {
  return (
    <span className="inline-flex items-center gap-2 text-sm text-zinc-400">
      <Loader2 className="size-4 animate-spin text-gold-400" />
      {label ?? "جارٍ التحميل…"}
    </span>
  );
}

/* ─── حبة حالة ─── */
export function Pill({ color, children }: { color: string; children: ReactNode }) {
  return (
    <span className="chip" style={{ color, borderColor: `${color}55`, background: `${color}14` }}>
      <span className="pulse-dot size-1.5 rounded-full" style={{ background: color }} />
      {children}
    </span>
  );
}
