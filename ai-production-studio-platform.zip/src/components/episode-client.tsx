"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import type { Asset, Episode, Scene } from "@/db/schema";
import { EPISODE_STATUSES, GATES, episodeStatusMeta } from "@/lib/studio";
import { CopyButton, EmptyState, FavToggle, Pill, Spinner } from "@/components/ui";
import { SceneCard } from "@/components/scene-card";
import {
  ArrowRight,
  CheckCircle2,
  FileArchive,
  FileJson,
  FileText,
  MonitorPlay,
  Plus,
  Printer,
  ShieldCheck,
  Sparkles,
  Trash2,
  TriangleAlert,
  Video,
  Wand2,
} from "lucide-react";

const VIDEO_OVERVIEW_TPL = (title: string) =>
  `اعرض أحداث حلقة «${title}» كمشاهد متسلسلة قصيرة، مستخدمًا صور الشخصيات من المصادر حصرًا، بنبرة سردية درامية. قدّم كل مشهد بلقطة واحدة واضحة، واذكر أسماء الشخصيات كما في بطاقاتها فقط، ولا تُظهر أي وجه ليس له مصدر CHAR.`;

export function EpisodeClient({
  initialEpisode,
  initialScenes,
  assets,
  styleLock,
  gatesAuto,
  missingAll,
}: {
  initialEpisode: Episode;
  initialScenes: Scene[];
  assets: Asset[];
  styleLock: string;
  gatesAuto: Record<string, boolean>;
  missingAll: { kind: string; label: string }[];
}) {
  const router = useRouter();
  const [ep, setEp] = useState(initialEpisode);
  const [scenesList, setScenesList] = useState(initialScenes);
  const [narrative, setNarrative] = useState(ep.narrative);
  const [notes, setNotes] = useState(ep.notes);
  const [title, setTitle] = useState(ep.title);
  const [breaking, setBreaking] = useState(false);
  const [breakInfo, setBreakInfo] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  const meta = episodeStatusMeta(ep.status);
  const approved = scenesList.filter((s) => s.status === "approved").length;
  const ready = scenesList.filter((s) => s.status !== "draft").length;

  const gates = useMemo(
    () =>
      GATES.map((g) => ({
        ...g,
        auto: gatesAuto[g.key] ?? false,
        manual: !!(ep.gates as Record<string, boolean>)[g.key],
      })),
    [ep.gates, gatesAuto]
  );
  const gatesPassed = gates.filter((g) => g.auto || g.manual).length;

  async function patchEpisode(patch: Record<string, unknown>) {
    const res = await fetch(`/api/episodes/${ep.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    if (res.ok) setEp(await res.json());
  }

  async function saveText() {
    setSaving(true);
    await patchEpisode({ title, narrative, notes });
    setSaving(false);
    setBreakInfo("حُفظ السرد — جاهز للتفكيك.");
    setTimeout(() => setBreakInfo(null), 2500);
  }

  async function runBreakdown() {
    setBreaking(true);
    setBreakInfo(null);
    try {
      const res = await fetch(`/api/episodes/${ep.id}/breakdown`, { method: "POST" });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      setBreakInfo(`${data.summary} — راجع البوابات قبل التوليد.`);
      const full = await fetch(`/api/episodes/${ep.id}`);
      const j = await full.json();
      setScenesList(j.scenes);
      setEp(j.episode);
      router.refresh();
    } catch (e) {
      setBreakInfo(e instanceof Error ? e.message : "فشل التفكيك");
    } finally {
      setBreaking(false);
    }
  }

  async function patchScene(id: string, patch: Record<string, unknown>) {
    setScenesList((p) => p.map((s) => (s.id === id ? ({ ...s, ...patch } as Scene) : s)));
    await fetch(`/api/scenes/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    router.refresh();
  }

  async function deleteScene(id: string) {
    setScenesList((p) => p.filter((s) => s.id !== id));
    await fetch(`/api/scenes/${id}`, { method: "DELETE" });
    router.refresh();
  }

  async function addScene() {
    const res = await fetch("/api/scenes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ episodeId: ep.id }),
    });
    const row = await res.json();
    setScenesList((p) => [...p, row].sort((a, b) => a.num - b.num));
  }

  async function deleteEpisode() {
    await fetch(`/api/episodes/${ep.id}`, { method: "DELETE" });
    router.push("/production");
  }

  return (
    <div className="space-y-8">
      {/* ═══ الترويسة ═══ */}
      <div className="glass rounded-3xl p-6">
        <div className="flex flex-wrap items-center gap-3">
          <Link href="/production" className="btn btn-ghost !px-3">
            <ArrowRight className="size-4" /> الإنتاج
          </Link>
          <span className="font-mono-en text-3xl font-extrabold text-gold-500" dir="ltr">
            {ep.code}
          </span>
          <input
            className="input !w-auto min-w-52 flex-1 !border-transparent !bg-transparent !text-xl font-bold text-white hover:!border-white/10 focus:!border-gold-500/50"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onBlur={() => title !== ep.title && patchEpisode({ title })}
          />
          <FavToggle on={ep.favorite} onToggle={() => patchEpisode({ favorite: !ep.favorite })} />
          <select
            className="select !w-auto !py-2 !text-xs"
            value={ep.status}
            onChange={(e) => patchEpisode({ status: e.target.value })}
          >
            {EPISODE_STATUSES.map((s) => (
              <option key={s.key} value={s.key}>
                {s.label}
              </option>
            ))}
          </select>
          <Pill color={meta.color}>{meta.label}</Pill>
          <button className="btn btn-danger !px-3" onClick={() => setConfirmDelete(true)} title="حذف الحلقة">
            <Trash2 className="size-4" />
          </button>
        </div>

        {/* شريط التصدير */}
        <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-white/[0.07] pt-5">
          <span className="text-[11px] font-bold text-zinc-500">التصدير والعرض:</span>
          <a href={`/api/export/episode/${ep.id}?format=zip`} className="btn btn-teal !px-3 !py-2 !text-[12px]">
            <FileArchive className="size-4" /> حزمة ZIP كاملة
          </a>
          <a href={`/api/export/episode/${ep.id}?format=md`} className="btn btn-ghost !px-3 !py-2 !text-[12px]">
            <FileText className="size-4" /> Markdown
          </a>
          <a href={`/api/export/episode/${ep.id}?format=json`} className="btn btn-ghost !px-3 !py-2 !text-[12px]">
            <FileJson className="size-4" /> JSON
          </a>
          <a href={`/production/${ep.id}/print`} target="_blank" className="btn btn-ghost !px-3 !py-2 !text-[12px]">
            <Printer className="size-4" /> PDF للطباعة
          </a>
          <Link href={`/slides/${ep.id}`} className="btn btn-gold !px-3 !py-2 !text-[12px]">
            <MonitorPlay className="size-4" /> عرض الشرائح
          </Link>
          <div className="ms-auto flex items-center gap-2">
            <span className="hidden text-[11px] text-zinc-500 lg:inline">تعليمة Video Overview:</span>
            <CopyButton small text={VIDEO_OVERVIEW_TPL(ep.title)} label="نسخ التعليمة" />
          </div>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* ═══ السرد والتفكيك ═══ */}
        <section className="glass space-y-4 rounded-3xl p-6 lg:col-span-3">
          <div className="flex items-center justify-between">
            <h2 className="display flex items-center gap-2 text-lg text-white">
              <FileText className="size-5 text-gold-400" /> السرد والملاحظات الإخراجية
            </h2>
            <button className="btn btn-ghost !px-3 !py-1.5 !text-[11px]" onClick={saveText} disabled={saving}>
              {saving ? <Spinner /> : "حفظ النص"}
            </button>
          </div>
          <textarea
            className="textarea !min-h-52"
            value={narrative}
            onChange={(e) => setNarrative(e.target.value)}
            placeholder="الصق السرد الخام هنا… المحرك سيقسّمه إلى مشاهد: مكان واحد + حدث واحد + انفعال واحد سائد."
          />
          <div>
            <label className="label">ملاحظات إخراجية</label>
            <textarea
              className="textarea !min-h-20"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مشهد الاغتيال: صدمة بمستوى انفجار — المشهد الأخير: انهيار بكاء — الخرائط من MAP المعتمدة."
            />
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button className="btn btn-gold" onClick={runBreakdown} disabled={breaking || !narrative.trim()}>
              {breaking ? <Spinner label="المحرك يفكك السرد…" /> : (
                <>
                  <Wand2 className="size-4" /> تفكيك السرد إلى مشاهد
                </>
              )}
            </button>
            {scenesList.length > 0 && (
              <span className="text-[11px] text-zinc-500">سيستبدل المشاهد الحالية بقراءة جديدة كاملة.</span>
            )}
          </div>
          {breakInfo && (
            <motion.p initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="rounded-xl border border-tealx-400/30 bg-tealx-400/10 p-3 text-[13px] text-tealx-400">
              {breakInfo}
            </motion.p>
          )}
        </section>

        {/* ═══ البوابات والنواقص ═══ */}
        <div className="space-y-6 lg:col-span-2">
          <section className="glass rounded-3xl p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="display flex items-center gap-2 text-lg text-white">
                <ShieldCheck className="size-5 text-emerald-400" /> بوابات الجودة
              </h2>
              <span className={`chip ${gatesPassed === 4 ? "!border-emerald-400/50 !bg-emerald-400/10 !text-emerald-400" : "!border-gold-500/50 !bg-gold-500/10 !text-gold-400"}`}>
                {gatesPassed}/4 جاهزة
              </span>
            </div>
            <div className="space-y-3">
              {gates.map((g) => (
                <div key={g.key} className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-3.5">
                  <div className="flex items-center gap-2.5">
                    <CheckCircle2 className={`size-5 ${g.auto || g.manual ? "text-emerald-400" : "text-zinc-600"}`} />
                    <p className="text-[13px] font-bold text-white">{g.title}</p>
                    <label className="ms-auto flex cursor-pointer items-center gap-1.5 text-[10px] text-zinc-500">
                      <input
                        type="checkbox"
                        className="size-3.5 accent-[#4ade80]"
                        checked={g.manual}
                        onChange={(e) =>
                          patchEpisode({ gates: { ...(ep.gates as Record<string, boolean>), [g.key]: e.target.checked } })
                        }
                      />
                      توقيع المخرج
                    </label>
                  </div>
                  <p className="mt-1.5 text-[11px] leading-5 text-zinc-500">{g.desc}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="glass rounded-3xl p-6">
            <h2 className="display mb-4 flex items-center gap-2 text-lg text-white">
              <TriangleAlert className="size-5 text-hotpink-500" /> نواقص مطلوبة
            </h2>
            {missingAll.length ? (
              <div className="space-y-2">
                {missingAll.map((m) => (
                  <div key={`${m.kind}-${m.label}`} className="flex items-center gap-3 rounded-xl border border-hotpink-500/25 bg-hotpink-500/[0.06] p-3">
                    <span className="chip !text-[10px]" dir="ltr">
                      {m.kind}
                    </span>
                    <span className="flex-1 text-[13px] font-bold text-white">{m.label}</span>
                    <Link
                      href={`/lab?type=${m.kind}&name=${encodeURIComponent(m.label)}`}
                      className="btn btn-teal !px-2.5 !py-1 !text-[10px]"
                    >
                      <Sparkles className="size-3" /> أنشئها
                    </Link>
                  </div>
                ))}
              </div>
            ) : (
              <p className="rounded-xl border border-emerald-400/25 bg-emerald-400/[0.06] p-4 text-[13px] leading-6 text-emerald-300">
                الحقيبة مكتملة لهذه الحلقة — لا اختراع ولا استعارة وجوه.
              </p>
            )}
            <div className="mt-4 flex flex-wrap gap-2 text-[11px] text-zinc-400">
              <span className="chip">{scenesList.length} مشهد</span>
              <span className="chip">{ready} بانتظار/بعد التوليد</span>
              <span className="chip">{approved} معتمد</span>
            </div>
          </section>
        </div>
      </div>

      {/* ═══ المشاهد ═══ */}
      <section>
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="sec-num mb-2">STORYBOARD SCENES</p>
            <h2 className="display text-2xl text-white">لوحة الاستوري بورد</h2>
          </div>
          <button className="btn btn-ghost" onClick={addScene}>
            <Plus className="size-4" /> مشهد يدوي
          </button>
        </div>

        {scenesList.length ? (
          <div className="space-y-4">
            <AnimatePresence>
              {scenesList.map((s) => (
                <SceneCard
                  key={s.id}
                  scene={s}
                  assets={assets}
                  styleLock={styleLock}
                  onPatch={patchScene}
                  onDelete={deleteScene}
                />
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <EmptyState
            icon={<Video className="size-7" />}
            title="لا مشاهد بعد"
            desc="احفظ السرد ثم اضغط «تفكيك السرد إلى مشاهد» — سيبني المحرك اللوحة كاملة ببرومبتات مقفلة على هويتك."
            action={
              <button className="btn btn-gold" onClick={runBreakdown} disabled={breaking || !narrative.trim()}>
                <Wand2 className="size-4" /> فكّك الآن
              </button>
            }
          />
        )}
      </section>

      {confirmDelete && (
        <div className="fixed inset-0 z-[100] grid place-items-center bg-black/70 p-4 backdrop-blur-sm" onClick={() => setConfirmDelete(false)}>
          <div className="glass w-full max-w-sm rounded-3xl bg-ink-900/95 p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="display text-lg text-white">حذف {ep.code} نهائيًا؟</h3>
            <p className="mt-2 text-sm leading-7 text-zinc-400">كل المشاهد والبرومبتات والتقدم سيُمحى من الأرشيف.</p>
            <div className="mt-5 flex justify-end gap-2">
              <button className="btn btn-ghost" onClick={() => setConfirmDelete(false)}>
                تراجع
              </button>
              <button className="btn btn-danger" onClick={deleteEpisode}>
                <Trash2 className="size-4" /> حذف نهائي
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
