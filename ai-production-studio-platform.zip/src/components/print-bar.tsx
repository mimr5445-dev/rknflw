"use client";

import Link from "next/link";
import { ArrowRight, Printer } from "lucide-react";

export function PrintBar({ backHref }: { backHref: string }) {
  return (
    <div className="no-print sticky top-0 z-50 mb-6 flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-ink-900/90 p-4 backdrop-blur-xl">
      <Link href={backHref} className="btn btn-ghost">
        <ArrowRight className="size-4" /> عودة لغرفة الإخراج
      </Link>
      <p className="hidden text-xs text-zinc-400 sm:block">
        ستُفتح نافذة الطباعة — اختر «حفظ كـ PDF» للحصول على ملف الحلقة الرسمي.
      </p>
      <button className="btn btn-gold" onClick={() => window.print()}>
        <Printer className="size-4" /> طباعة / حفظ PDF
      </button>
    </div>
  );
}
