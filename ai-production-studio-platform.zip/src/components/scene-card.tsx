"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import type { Asset, Scene } from "@/db/schema";
import {
  CAMERAS,
  EXPRESSIONS,
  LIGHTINGS,
  NEGATIVE_DEFAULT,
  assemblePrompt,
  displayName,
  pad2,
  sceneStatusMeta,
  SCENE_STATUSES,
} from "@/lib/studio";
import { CopyButton, TypeChip } from "@/components/ui";
import { UploadField } from "@/components/upload-field";
import {
  Camera,
  ChevronDown,
  Lightbulb,
  Map as MapIcon,
  RefreshCcw,
  Save,
  Smile,
  Trash2,
  TriangleAlert,
} from "lucide-react";

interface MissingRef {
  kind: string;
  label: string;
}

/** يعيد بناء حقول البرومبت من البيانات الوصفية الحالية */
export function rebuildPromptParts(scene: Scene, assets: Asset[], styleLock: string) {
  const byId = new Map(assets.map((a) => [a.id, a]));
  const chars = ((scene.characterIds as string[]) || []).map((c) => byId.get(c)).filter(Boolean) as Asset[];
  const map = scene.mapId ? byId.get(scene.mapId) : undefined;
  const bg = scene.bgId ? byId.get(scene.bgId) : undefined;
  const props = ((scene.propIds as string[]) || []).map((c) => byId.get(c)).filter(Boolean) as Asset[];

  const refLines: string[] = [];
  chars.forEach((c) => refLines.push(`attach exact reference: “${displayName(c)}”`));
  if (map) refLines.push(`attach base map (do NOT redraw borders): “${displayName(map)}”`);
  if (bg) refLines.push(`attach location plate: “${displayName(bg)}”`);
  props.forEach((p) => refLines.push(`attach prop reference: “${displayName(p)}”`));

  const cameraEn = CAMERAS.find((c) => c.ar === scene.camera)?.en ?? "medium shot";
  const lightEn = LIGHTINGS.find((l) => l.ar === scene.lighting)?.en ?? "cinematic light";
  const exprEn = EXPRESSIONS.find((e) => e.ar === scene.expression)?.en ?? "natural expression";
  const namesEn = chars.map((c) => c.nameEn || c.name);

  const promptScene = [
    `${cameraEn} — ${namesEn.length ? namesEn.join(" and ") : "the scene"}${scene.locationText ? ` at ${scene.locationText}` : ""}.`,
    map
      ? "Keep the map geography pixel-identical to the attached base map — only add arrows, flags and explosion markers."
      : "Keep faces, hair, outfits and props pixel-identical to the attached references.",
    `${lightEn}.`,
  ].join(" ");

  const promptExpression = chars.length
    ? chars
        .map((c) => `${c.nameEn || c.name}: ${exprEn} — only eyes, eyebrows and mouth change; identity locked to the reference.`)
        .join("\n")
    : "no characters — scenery/map shot; geometry and colors identical to the attached reference.";

  return {
    promptRef: refLines.join("\n"),
    promptScene,
    promptExpression,
    promptStyle: styleLock || scene.promptStyle,
    promptNegative: scene.promptNegative || NEGATIVE_DEFAULT,
    expressionEn: exprEn,
  };
}

export function SceneCard({
  scene,
  assets,
  styleLock,
  onPatch,
  onDelete,
}: {
  scene: Scene;
  assets: Asset[];
  styleLock: string;
  onPatch: (id: string, patch: Record<string, unknown>) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
}) {
  const [open, setOpen] = useState(false);
  const [draft, setDraft] = useState<Scene | null>(null);
  const [saving, setSaving] = useState(false);
  const [armDelete, setArmDelete] = useState(false);

  const meta = sceneStatusMeta(scene.status);
  const byId = new Map(assets.map((a) => [a.id, a]));
  const actors = [
    ...((scene.characterIds as string[]) || []).map((c) => byId.get(c)),
    scene.mapId ? byId.get(scene.mapId) : undefined,
    scene.bgId ? byId.get(scene.bgId) : undefined,
    ...((scene.propIds as string[]) || []).map((c) => byId.get(c)),
  ].filter(Boolean) as Asset[];
  const missing = (scene.missing as MissingRef[]) || [];
  const full = assemblePrompt(scene);

  function startEdit() {
    setDraft({ ...scene });
    setOpen(true);
  }

  async function saveDraft() {
    if (!draft) return;
    setSaving(true);
    await onPatch(scene.id, {
      title: draft.title,
      narration: draft.narration,
      expression: draft.expression,
      expressionEn: draft.expressionEn,
      camera: draft.camera,
      lighting: draft.lighting,
      locationText: draft.locationText,
      promptRef: draft.promptRef,
      promptScene: draft.promptScene,
      promptExpression: draft.promptExpression,
      promptStyle: draft.promptStyle,
      promptNegative: draft.promptNegative,
      notes: draft.notes,
    });
    setSaving(false);
    setDraft(null);
  }

  async function rebuild() {
    const parts = rebuildPromptParts(scene, assets, styleLock);
    await onPatch(scene.id, parts);
    if (draft) setDraft({ ...draft, ...parts });
  }

  const d = draft;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.97 }}
      className="glass overflow-hidden rounded-3xl"
    >
      {/* الرأس */}
      <div className="flex flex-wrap items-center gap-4 p-5">
        <span className="grid size-14 shrink-0 place-items-center rounded-2xl border border-gold-500/25 bg-gold-500/[0.08] font-mono-en text-xl font-extrabold text-gold-400" dir="ltr">
          {pad2(scene.num)}
        </span>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <h3 className="display text-base text-white">{scene.title}</h3>
            {scene.isMap && (
              <span className="chip !border-tealx-400/40 !bg-tealx-400/10 !text-tealx-400 !text-[10px]">
                <MapIcon className="size-3" /> مشهد خريطة
              </span>
            )}
            {missing.map((m) => (
              <span key={`${m.kind}-${m.label}`} className="chip !border-hotpink-500/40 !bg-hotpink-500/10 !text-hotpink-500 !text-[10px]">
                <TriangleAlert className="size-3" /> ناقص: {m.label}
              </span>
            ))}
          </div>
          <p className="mt-1 line-clamp-2 text-[12px] leading-6 text-zinc-400">{scene.narration}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <span className="chip !text-[10px]">
            <Smile className="size-3 text-gold-400" /> {scene.expression}
          </span>
          <span className="chip !text-[10px]">
            <Camera className="size-3 text-sky-400" /> {scene.camera}
          </span>
          <span className="chip !text-[10px]">
            <Lightbulb className="size-3 text-violet-400" /> {scene.lighting}
          </span>
          <span className="chip" style={{ color: meta.color, borderColor: `${meta.color}55`, background: `${meta.color}14` }}>
            {meta.label}
          </span>
          <CopyButton small text={full} label="البرومبت" />
          <button className="btn btn-ghost !px-2.5 !py-1.5 !text-[11px]" onClick={() => (open ? (setOpen(false), setDraft(null)) : startEdit())}>
            <ChevronDown className={`size-4 transition-transform ${open ? "rotate-180" : ""}`} />
            {open ? "طيّ" : "تحرير"}
          </button>
        </div>
      </div>

      {/* الموسّع */}
      {open && d && (
        <div className="border-t border-white/[0.07] bg-black/20 p-5">
          <div className="grid gap-5 lg:grid-cols-2">
            {/* البيانات الوصفية */}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label">عنوان المشهد</label>
                  <input className="input" value={d.title} onChange={(e) => setDraft({ ...d, title: e.target.value })} />
                </div>
                <div>
                  <label className="label">الموقع</label>
                  <input className="input" value={d.locationText ?? ""} onChange={(e) => setDraft({ ...d, locationText: e.target.value })} />
                </div>
              </div>
              <div>
                <label className="label">السرد</label>
                <textarea className="textarea !min-h-20" value={d.narration} onChange={(e) => setDraft({ ...d, narration: e.target.value })} />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="label">التعبير المطاطي</label>
                  <select
                    className="select"
                    value={d.expression}
                    onChange={(e) =>
                      setDraft({
                        ...d,
                        expression: e.target.value,
                        expressionEn: EXPRESSIONS.find((x) => x.ar === e.target.value)?.en ?? "",
                      })
                    }
                  >
                    {EXPRESSIONS.map((x) => (
                      <option key={x.ar} value={x.ar}>
                        {x.ar}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">الكادر</label>
                  <select className="select" value={d.camera} onChange={(e) => setDraft({ ...d, camera: e.target.value })}>
                    {CAMERAS.map((x) => (
                      <option key={x.ar} value={x.ar}>
                        {x.ar}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="label">الإضاءة</label>
                  <select className="select" value={d.lighting} onChange={(e) => setDraft({ ...d, lighting: e.target.value })}>
                    {LIGHTINGS.map((x) => (
                      <option key={x.ar} value={x.ar}>
                        {x.ar}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {/* الممثلون */}
              <div>
                <label className="label">الممثلون من المصادر</label>
                <div className="flex flex-wrap gap-1.5">
                  {actors.length ? actors.map((a) => <TypeChip key={a.id} type={a.type} />) : <span className="text-xs text-zinc-500">لا أحد — مشهد خالٍ من الشخصيات</span>}
                </div>
                {actors.length > 0 && (
                  <p className="mt-1.5 font-mono-en text-[10px] leading-5 text-zinc-500" dir="ltr">
                    {actors.map((a) => displayName(a)).join(" · ")}
                  </p>
                )}
              </div>

              {/* الشريحة */}
              <div>
                <label className="label">الشريحة المولّدة (تُرفق في التصدير وعرض الشرائح)</label>
                <UploadField
                  value={d.imagePath}
                  onChange={(p) => {
                    setDraft({ ...d, imagePath: p });
                    onPatch(scene.id, {
                      imagePath: p,
                      status: p ? (scene.status === "draft" ? "generated" : scene.status) : "draft",
                    });
                  }}
                  hint="ارفع ناتج أداة التوليد بعد مراجعة الهوية"
                />
              </div>

              {/* الحالة */}
              <div>
                <label className="label">حالة المشهد</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {SCENE_STATUSES.map((s) => (
                    <button
                      key={s.key}
                      className={`rounded-lg border px-1 py-2 text-[10px] font-bold transition-all ${
                        scene.status === s.key ? "border-transparent text-ink-950" : "border-white/10 bg-white/[0.03] text-zinc-400 hover:text-white"
                      }`}
                      style={scene.status === s.key ? { background: s.color } : {}}
                      onClick={() => onPatch(scene.id, { status: s.key })}
                    >
                      {s.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* البرومبت */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="label !mb-0">كتلة البرومبت النهائية</label>
                <div className="flex gap-2">
                  <button className="btn btn-ghost !px-2.5 !py-1.5 !text-[10px]" onClick={rebuild} title="إعادة بناء الحقول من البيانات الوصفية + النمط المقدس">
                    <RefreshCcw className="size-3.5" /> إعادة بناء
                  </button>
                  <CopyButton small text={assemblePrompt(d)} label="نسخ" />
                </div>
              </div>
              <div>
                <label className="label">[REF] — المراجع المرفقة</label>
                <textarea className="textarea !min-h-16 font-mono-en !text-[11px]" dir="ltr" value={d.promptRef} onChange={(e) => setDraft({ ...d, promptRef: e.target.value })} />
              </div>
              <div>
                <label className="label">[SCENE]</label>
                <textarea className="textarea !min-h-20 font-mono-en !text-[11px]" dir="ltr" value={d.promptScene} onChange={(e) => setDraft({ ...d, promptScene: e.target.value })} />
              </div>
              <div>
                <label className="label">[EXPRESSION]</label>
                <textarea className="textarea !min-h-16 font-mono-en !text-[11px]" dir="ltr" value={d.promptExpression} onChange={(e) => setDraft({ ...d, promptExpression: e.target.value })} />
              </div>
              <div className="grid grid-cols-1 gap-3">
                <div>
                  <label className="label">[STYLE LOCK]</label>
                  <textarea className="textarea !min-h-16 font-mono-en !text-[11px]" dir="ltr" value={d.promptStyle} onChange={(e) => setDraft({ ...d, promptStyle: e.target.value })} />
                </div>
                <div>
                  <label className="label">[NEGATIVE]</label>
                  <textarea className="textarea !min-h-12 font-mono-en !text-[11px]" dir="ltr" value={d.promptNegative} onChange={(e) => setDraft({ ...d, promptNegative: e.target.value })} />
                </div>
              </div>
            </div>
          </div>

          <div className="mt-5 flex items-center justify-between border-t border-white/[0.07] pt-4">
            <button
              className={`btn ${armDelete ? "btn-danger" : "btn-ghost"} !text-[11px]`}
              onClick={async () => {
                if (!armDelete) return setArmDelete(true);
                await onDelete(scene.id);
              }}
              onBlur={() => setArmDelete(false)}
            >
              <Trash2 className="size-3.5" /> {armDelete ? "تأكيد حذف المشهد؟" : "حذف المشهد"}
            </button>
            <button className="btn btn-gold" onClick={saveDraft} disabled={saving}>
              <Save className="size-4" /> {saving ? "يُحفظ…" : "حفظ التعديلات"}
            </button>
          </div>
        </div>
      )}
    </motion.article>
  );
}
