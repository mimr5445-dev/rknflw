"use client";

import { useEffect, useState } from "react";
import type { Asset } from "@/db/schema";
import { EXPRESSIONS, NEGATIVE_DEFAULT, SOURCE_TYPES, displayName, type SourceTypeKey } from "@/lib/studio";
import { Modal } from "@/components/ui";
import { UploadField } from "@/components/upload-field";
import { Save, Sparkles } from "lucide-react";

export interface AssetDraft {
  id?: string;
  type: SourceTypeKey;
  name: string;
  nameEn: string;
  role: string;
  era: string;
  description: string;
  prompt: string;
  styleLock: string;
  imagePath: string | null;
  favorite: boolean;
}

export function draftFromAsset(a: Asset): AssetDraft {
  return {
    id: a.id,
    type: a.type as SourceTypeKey,
    name: a.name,
    nameEn: a.nameEn ?? "",
    role: a.role ?? "",
    era: a.era ?? "",
    description: a.description ?? "",
    prompt: a.prompt ?? "",
    styleLock: a.styleLock ?? "",
    imagePath: a.imagePath,
    favorite: a.favorite,
  };
}

export function emptyDraft(type: SourceTypeKey = "CHAR", prefillName = ""): AssetDraft {
  return {
    type,
    name: prefillName,
    nameEn: "",
    role: "",
    era: "",
    description: "",
    prompt: "",
    styleLock: type === "STYLE" ? "" : "",
    imagePath: null,
    favorite: false,
  };
}

export function AssetFormModal({
  open,
  draft,
  onClose,
  onSaved,
  onChange,
}: {
  open: boolean;
  draft: AssetDraft | null;
  onClose: () => void;
  onSaved: () => void;
  onChange: (d: AssetDraft) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const d = draft;

  useEffect(() => setErr(null), [draft?.id, open]);
  if (!d) return null;

  const dd: AssetDraft = d;
  const set = (patch: Partial<AssetDraft>) => onChange({ ...dd, ...patch });
  const isCharLike = dd.type === "CHAR" || dd.type === "CHAR-EXP";
  const withImage = dd.type !== "RULE";
  const previewName = displayName({ type: dd.type, name: dd.name || "…", role: dd.role || null, era: dd.era || null } as Asset);

  async function save() {
    if (!dd.name.trim()) {
      setErr("اسم المصدر مطلوب — هو بطاقة هويته");
      return;
    }
    setBusy(true);
    setErr(null);
    try {
      const payload = {
        ...dd,
        role: dd.role || null,
        era: dd.era || null,
        nameEn: dd.nameEn || null,
        description: dd.description || null,
        prompt: dd.prompt || null,
        styleLock: dd.type === "STYLE" ? dd.styleLock || null : null,
      };
      const res = await fetch(dd.id ? `/api/assets/${dd.id}` : "/api/assets", {
        method: dd.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "فشل الحفظ");
      onSaved();
      onClose();
    } catch (e) {
      setErr(e instanceof Error ? e.message : "فشل الحفظ");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal open={open} onClose={onClose} title={d.id ? "تعديل المصدر" : "مصدر جديد للحقيبة المقدسة"} wide>
      <div className="grid gap-5 md:grid-cols-2">
        <div className="space-y-4">
          <div>
            <label className="label">نوع المصدر (بروتوكول التسمية)</label>
            <div className="grid grid-cols-4 gap-1.5">
              {SOURCE_TYPES.map((t) => (
                <button
                  key={t.key}
                  type="button"
                  onClick={() => set({ type: t.key })}
                  className={`rounded-lg border px-1 py-2 font-mono-en text-[10px] font-bold transition-all ${
                    d.type === t.key ? "border-transparent text-ink-950" : "border-white/10 bg-white/[0.03] text-zinc-400 hover:text-white"
                  }`}
                  style={d.type === t.key ? { background: t.color } : {}}
                  dir="ltr"
                >
                  {t.key}
                </button>
              ))}
            </div>
            <p className="mt-1.5 text-[11px] leading-5 text-zinc-500">
              {SOURCE_TYPES.find((t) => t.key === d.type)?.hint}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="label">الاسم *</label>
              <input className="input" value={d.name} onChange={(e) => set({ name: e.target.value })} placeholder="ترامب" />
            </div>
            <div>
              <label className="label">الاسم الإنجليزي (للبرومبت)</label>
              <input className="input" dir="ltr" value={d.nameEn} onChange={(e) => set({ nameEn: e.target.value })} placeholder="Donald Trump" />
            </div>
          </div>

          {(isCharLike || d.type === "BG" || d.type === "PROP" || d.type === "MAP-STYLE" || d.type === "RULE" || d.type === "STYLE") && (
            <div>
              <label className="label">{d.type === "CHAR" ? "الوظيفة (تظهر في بطاقة الهوية)" : "الدور داخل النظام"}</label>
              <input
                className="input"
                value={d.role}
                onChange={(e) => set({ role: e.target.value })}
                placeholder={d.type === "CHAR" ? "رئيس الولايات المتحدة 2017–2021" : "ما الذي يفعله هذا المصدر؟"}
              />
            </div>
          )}

          {d.type === "MAP" && (
            <div>
              <label className="label">الفترة الزمنية للخريطة</label>
              <input className="input" value={d.era} onChange={(e) => set({ era: e.target.value })} placeholder="1914 / العصر الحديث…" />
            </div>
          )}

          <div>
            <label className="label">وصف الهوية (قفل الملامح)</label>
            <textarea
              className="textarea !min-h-20"
              value={d.description}
              onChange={(e) => set({ description: e.target.value })}
              placeholder="الشعر، البدلة، الدبوس، الشنب… كل ما لا يتغير أبدًا."
            />
          </div>
        </div>

        <div className="space-y-4">
          {withImage && (
            <div>
              <label className="label">الصورة المرجعية</label>
              <UploadField value={d.imagePath} onChange={(p) => set({ imagePath: p })} hint="PNG أو JPG — جودة عالية" />
            </div>
          )}

          {d.type === "STYLE" && (
            <>
              <div>
                <label className="label">STYLE LOCK — سطر النمط المقدس (EN)</label>
                <textarea
                  className="textarea !min-h-20 font-mono-en text-xs"
                  dir="ltr"
                  value={d.styleLock}
                  onChange={(e) => set({ styleLock: e.target.value })}
                  placeholder="flat 2D rubber-face caricature, thick clean black outlines…"
                />
              </div>
              <div className="rounded-xl border border-white/10 bg-white/[0.03] p-3">
                <p className="label !mb-2">جدول التعابير المعتمدة</p>
                <div className="flex flex-wrap gap-1.5">
                  {EXPRESSIONS.map((x) => (
                    <span key={x.ar} className="chip !text-[10px]">
                      {x.ar} — {x.hint}
                    </span>
                  ))}
                </div>
                <p className="mt-2 text-[10px] leading-5 text-zinc-500" dir="ltr">
                  NEGATIVE: {NEGATIVE_DEFAULT}
                </p>
              </div>
            </>
          )}

          <div>
            <label className="label">تعليمات الاستخدام (تُصدَّر مع الصورة في حزمة ZIP)</label>
            <textarea
              className="textarea !min-h-20"
              value={d.prompt}
              onChange={(e) => set({ prompt: e.target.value })}
              placeholder="متى يُرفق هذا المرجع؟ وما الممنوع تغييره؟"
            />
          </div>

          <label className="flex cursor-pointer items-center gap-2 text-sm text-zinc-300">
            <input
              type="checkbox"
              className="size-4 accent-[#e9b44c]"
              checked={d.favorite}
              onChange={(e) => set({ favorite: e.target.checked })}
            />
            مصدر مقدس مميز (نجمة)
          </label>
        </div>
      </div>

      {/* معاينة اسم المصدر الرسمي */}
      <div className="mt-5 rounded-xl border border-gold-500/25 bg-gold-500/[0.07] p-3">
        <p className="label !mb-1 !text-gold-400">اسم المصدر كما سيُقرأ في NotebookLM</p>
        <p className="font-mono-en text-sm font-bold text-white" dir="ltr">
          {previewName}
        </p>
      </div>

      {err && <p className="mt-3 text-sm text-hotpink-500">{err}</p>}

      <div className="mt-5 flex justify-end gap-2">
        <button className="btn btn-ghost" onClick={onClose}>
          إلغاء
        </button>
        <button className="btn btn-gold" onClick={save} disabled={busy}>
          {busy ? <Sparkles className="size-4 animate-spin" /> : <Save className="size-4" />}
          {d.id ? "حفظ التعديلات" : "إضافة للحقيبة"}
        </button>
      </div>
    </Modal>
  );
}
