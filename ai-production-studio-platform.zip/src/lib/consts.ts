/** ثوابت الإنتاج الافتراضية (مشتركة بين الخادم والمحرك) */

export const NEGATIVE_DEFAULT =
  "no nose, no lips, no anime, no 3D, no realism, no gradient, no texture, no blur, no detailed background";

/** سطر النمط الاحتياطي إذا لم يوجد مصدر STYLE في المكتبة */
export const SEED_FALLBACK_STYLE_LOCK =
  "flat 2D rubber-face caricature, thick clean black outlines, solid flat colors, exaggerated stretchy facial expressions, simple oval eyes, no nose, no lips, matte paper background, cinematic flat lighting, 16:9 frame";
