import type { Asset, Episode, Scene } from "@/db/schema";
import { assemblePrompt, displayName, pad2 } from "@/lib/studio";

/* ─────────────────────────────────────────────────────────────
   بنّاء حزم التصدير — نص Markdown كامل مطابق لصيغة الخطة
   تُرسل هذه الحزمة لأي نموذج ذكاء فيفهم المشروع كاملًا
   ───────────────────────────────────────────────────────────── */

export interface MissingRef {
  kind: string;
  label: string;
}

export function assetManifestLine(a: Asset): string {
  return `- **${displayName(a)}**${a.favorite ? " (مقدس)" : ""}\n  - التعليمات: ${a.prompt || a.description || "—"}`;
}

export function buildIdentityMarkdown(all: Asset[]): string {
  const byType = (t: string) => all.filter((a) => a.type === t);
  const sec = (title: string, list: Asset[]) =>
    list.length ? `\n## ${title}\n\n${list.map(assetManifestLine).join("\n")}\n` : "";

  return `# حزمة الهوية المقدسة — استوديو الهوية الثابتة
> هذه الحزمة هي العالم الوحيد للمشروع. كل شخصية وخريطة وعنصر يأتي من هنا حصرًا. ما ليس هنا لا يُخترع.
${sec("RULE — دستور الاستوديو", byType("RULE"))}
${sec("STYLE — دليل الفن", byType("STYLE"))}
${sec("CHAR — حقيبة الممثلين", byType("CHAR"))}
${sec("CHAR-EXP — أوراق التعابير", byType("CHAR-EXP"))}
${sec("MAP — أطلس الخرائط", byType("MAP"))}
${sec("MAP-STYLE — أنماط الخرائط", byType("MAP-STYLE"))}
${sec("BG — مواقع التصوير", byType("BG"))}
${sec("PROP — العناصر المتكررة", byType("PROP"))}
---
قاعدة التسمية: أسماء المصادر أعلاه تُستخدم حرفيًا عند الاستشهاد في كل مشهد.`;
}

export function sceneBlock(s: Scene, assetsById: Map<string, Asset>): string {
  const actors = [
    ...((s.characterIds as string[]) || [])
      .map((c) => assetsById.get(c))
      .filter(Boolean)
      .map((a) => displayName(a as Asset)),
    s.mapId && assetsById.get(s.mapId) ? displayName(assetsById.get(s.mapId)!) : null,
    s.bgId && assetsById.get(s.bgId) ? displayName(assetsById.get(s.bgId)!) : null,
    ...((s.propIds as string[]) || [])
      .map((c) => assetsById.get(c))
      .filter(Boolean)
      .map((a) => displayName(a as Asset)),
  ]
    .filter(Boolean)
    .join(" ، ");

  return `### SCENE ${pad2(s.num)} — ${s.title}

- **السرد:** ${s.narration}
- **الممثلون من المصادر:** ${actors || "لا أحد — مشهد خالٍ من الشخصيات"}
- **التعبير المطاطي:** ${s.expression}
- **الكادر:** ${s.camera}
- **الإضاءة المزاجية:** ${s.lighting}
- **الحالة:** ${s.status}

\`\`\`text
${assemblePrompt(s)}
\`\`\`
${(s.missing as MissingRef[])?.length ? `> نواقص المشهد: ${(s.missing as MissingRef[]).map((m) => `${m.kind} ← ${m.label}`).join(" ، ")}` : ""}`;
}

export function buildEpisodeMarkdown(ep: Episode, scenesList: Scene[], all: Asset[]): string {
  const assetsById = new Map(all.map((a) => [a.id, a]));
  const missingAll: MissingRef[] = [];
  for (const s of scenesList) {
    for (const m of (s.missing as MissingRef[]) || []) {
      if (!missingAll.some((x) => x.kind === m.kind && x.label === m.label)) missingAll.push(m);
    }
  }

  const summaryTable = scenesList.length
    ? `| # | العنوان | التعبير | الكادر | خريطة | الحالة |
|---|---|---|---|---|---|
${scenesList
  .map((s) => `| ${pad2(s.num)} | ${s.title} | ${s.expression} | ${s.camera} | ${s.isMap ? "نعم" : "—"} | ${s.status} |`)
  .join("\n")}`
    : "لا مشاهد بعد.";

  return `# ${ep.code} — ${ep.title}
> حزمة إنتاج كاملة من استوديو الهوية الثابتة. أرسلها لأي نموذج مع حزمة الهوية ليفهم المشروع بالكامل ويبني المشاهد.

## السرد الخام
${ep.narrative || "—"}

## الملاحظات الإخراجية
${ep.notes || "—"}

---

## المشاهد (${scenesList.length})
${scenesList.map((s) => sceneBlock(s, assetsById)).join("\n\n")}

---

## جدول الملخص
${summaryTable}

## نواقص مطلوبة قبل التوليد
${missingAll.length ? missingAll.map((m) => `- أنشئ مرجع **${m.kind}** لـ «${m.label}»`).join("\n") : "لا نواقص — الحقيبة مكتملة لهذه الحلقة."}

## تأكيد الاستمرارية
كل شخصية في هذه الحلقة مستدعاة من مصدر CHAR الخاص بها بنفس الهوية، والخريطة والنمط لم يتغيرا في أي مشهد.`;
}
