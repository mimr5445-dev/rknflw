import { NEGATIVE_DEFAULT, displayName } from "@/lib/studio";

/* ─────────────────────────────────────────────────────────────
   محرك تفكيك السرد — "العقل" المحلي للاستوديو
   يقرأ السرد العربي ويخرج مشاهد مهيكلة مطابقة لدستور الاستوديو:
   شخصيات من المصادر حصرًا، خرائط تُستدعى ولا تُخترع،
   تعابير وكادرات وإضاءة مستنتجة من النبرة الدرامية للنص.
   ───────────────────────────────────────────────────────────── */

export interface EngineAsset {
  id: string;
  type: string;
  name: string;
  role: string | null;
  nameEn: string | null;
  era: string | null;
}

export interface MissingRef {
  kind: "CHAR" | "MAP" | "PROP" | "BG";
  label: string;
}

export interface EngineScene {
  num: number;
  title: string;
  narration: string;
  expression: string;
  expressionEn: string;
  camera: string;
  lighting: string;
  locationText: string | null;
  promptRef: string;
  promptScene: string;
  promptExpression: string;
  promptStyle: string;
  promptNegative: string;
  characterIds: string[];
  mapId: string | null;
  bgId: string | null;
  propIds: string[];
  missing: MissingRef[];
  isMap: boolean;
}

export interface EngineResult {
  scenes: EngineScene[];
  missing: MissingRef[];
  summary: string;
}

/* ─── معاجم عربية للنبرة الدرامية (مرتبة حسب الأولوية) ─── */
const EMOTION_LEXICON: {
  key: string;
  en: string;
  words: string[];
  camera: string;
  lighting: string;
  beatEn: string;
}[] = [
  {
    key: "انفجار",
    en: "explosive rage, wide eyes, screaming mouth, stretched rubber face",
    words: ["انفجر", "انفجار", "ثار", "ثورة غضب", "اقتحم", "أعلن الحرب", "إعلان الحرب", "اشتعلت"],
    camera: "لقطة قريبة — زاوية منخفضة",
    lighting: "غسل أحمر للغضب",
    beatEn: "an explosive outburst tearing the room apart",
  },
  {
    key: "صدمة",
    en: "shocked, wide oval eyes, dropped jaw",
    words: ["اغتيال", "اغتيل", "اغتال", "رصاصة", "صدمة", "صُدم", "مفاجأة", "سقوط مفاجئ", "خبر صادم"],
    camera: "لقطة قريبة — زاوية منخفضة",
    lighting: "فلاش قاسٍ للصدمة",
    beatEn: "a shocking, frozen-in-time moment of disbelief",
  },
  {
    key: "غضب",
    en: "angry, thick furrowed brows, open shouting mouth",
    words: ["غضب", "غاضب", "صرخ", "توعد", "هدد", "تهديد", "احتدم", "غضبه", "غضبًا"],
    camera: "لقطة متوسطة — مستوى النظر",
    lighting: "غسل أحمر للغضب",
    beatEn: "barely contained anger about to erupt",
  },
  {
    key: "بكاء",
    en: "crying hard, trembling mouth, big tears",
    words: ["بكى", "بكاء", "دموع", "انهار", "رحيل", "فقد", "مأساة", "حداد", "مات"],
    camera: "لقطة قريبة بطيئة",
    lighting: "أزرق بارد للحزن",
    beatEn: "a devastating emotional collapse",
  },
  {
    key: "فرح",
    en: "wide joyful smile, bright sparkling eyes",
    words: ["فرح", "احتفل", "انتصر", "نصر", "انتصار", "ابتهج", "سعيد", "اتفاق", "سلام"],
    camera: "لقطة متوسطة — مستوى النظر",
    lighting: "دفء ذهبي للنصر",
    beatEn: "a burst of triumph and joy",
  },
  {
    key: "سخرية",
    en: "sarcastic smirk, one raised brow, half-closed eyes",
    words: ["سخر", "استهزأ", "بسخرية", "تهكم", "ابتسم ابتسامة"],
    camera: "لقطة متوسطة — مستوى النظر",
    lighting: "تيل محايد سينمائي",
    beatEn: "a sly, sarcastic beat",
  },
  {
    key: "انزعاج",
    en: "mildly annoyed, furrowed brows, tight mouth",
    words: ["انزعج", "قلق", "توتر", "خشي", "رفض", "إنذار", "تحذير", "أزمة", "تحشد"],
    camera: "لقطة متوسطة — مستوى النظر",
    lighting: "توتر رمادي بارد",
    beatEn: "rising tension and unease",
  },
  {
    key: "محايد",
    en: "neutral, composed face",
    words: [],
    camera: "لقطة متوسطة — مستوى النظر",
    lighting: "تيل محايد سينمائي",
    beatEn: "a calm, deliberate storytelling beat",
  },
];

/* ─── قاموس المناطق الجغرافية ─── */
const REGIONS: { keys: string[]; label: string; en: string }[] = [
  { keys: ["أوروبا", "اوروبا"], label: "أوروبا", en: "Europe" },
  { keys: ["فرنسا"], label: "فرنسا", en: "France" },
  { keys: ["ألمانيا", "المانيا"], label: "ألمانيا", en: "Germany" },
  { keys: ["روسيا"], label: "روسيا", en: "Russia" },
  { keys: ["النمسا", "المجر"], label: "النمسا-المجر", en: "Austria-Hungary" },
  { keys: ["صربيا", "البلقان", "سراييفو"], label: "البلقان", en: "the Balkans" },
  { keys: ["بريطانيا", "إنجلترا", "انجلترا"], label: "بريطانيا", en: "Britain" },
  { keys: ["الشرق الأوسط", "الشرق الاوسط"], label: "الشرق الأوسط", en: "the Middle East" },
  { keys: ["الخليج"], label: "الخليج", en: "the Gulf" },
  { keys: ["أفريقيا", "افريقيا"], label: "أفريقيا", en: "Africa" },
  { keys: ["آسيا", "اسيا"], label: "آسيا", en: "Asia" },
  { keys: ["أمريكا", "امريكا", "الولايات المتحدة"], label: "أمريكا", en: "the United States" },
  { keys: ["العالم"], label: "العالم", en: "the world" },
];

/* ─── شخصيات شهيرة تُرصد إن لم تكن في المكتبة (نواقص) ─── */
const FAMOUS_FIGURES: { keys: string[]; label: string }[] = [
  { keys: ["برينسيب"], label: "غافريلو برينسيب" },
  { keys: ["هتلر"], label: "أدولف هتلر" },
  { keys: ["ستالين"], label: "جوزيف ستالين" },
  { keys: ["تشرشل"], label: "وينستون تشرشل" },
  { keys: ["موسوليني"], label: "بينيتو موسوليني" },
  { keys: ["نابليون"], label: "نابليون بونابرت" },
  { keys: ["غاندي"], label: "المهاتما غاندي" },
  { keys: ["لينين"], label: "فلاديمير لينين" },
  { keys: ["فرانز جوزيف"], label: "الإمبراطور فرانز جوزيف" },
  { keys: ["ويلسون"], label: "وودرو ويلسون" },
  { keys: ["كليمنصو"], label: "جورج كليمنصو" },
  { keys: ["صدام"], label: "صدام حسين" },
  { keys: ["القذافي"], label: "معمر القذافي" },
  { keys: ["بوتين"], label: "فلاديمير بوتين" },
];

const BG_HINTS = [
  { keys: ["مكتب", "غرفة", "قصر", "مقر", "قاعة"], bucket: ["غرفة", "مكتب", "قصر", "مقر"] },
  { keys: ["خندق", "جبهة", "ميدان", "معركة", "ساحة"], bucket: ["خندق", "جبهة", "ميدان"] },
  { keys: ["شارع", "مدينة", "سراييفو", "ساحة عامة"], bucket: ["شارع", "مدينة"] },
];

const CAMERA_EN: Record<string, string> = {
  "لقطة متوسطة — مستوى النظر": "medium shot, eye-level angle",
  "لقطة قريبة — زاوية منخفضة": "tight close-up, low heroic angle",
  "لقطة قريبة بطيئة": "slow push-in close-up, eye-level",
  "لقطة واسعة — زاوية جوية": "wide establishing shot, high aerial angle",
  "لقطة واسعة — مستوى الأرض": "wide shot, ground-level angle",
  "كتف إلى كتف — مواجهة": "over-the-shoulder confrontation framing",
};

const LIGHT_EN: Record<string, string> = {
  "تيل محايد سينمائي": "cinematic neutral teal grade, soft key light",
  "غسل أحمر للغضب": "heavy red anger wash flooding the frame",
  "أزرق بارد للحزن": "cold blue sorrow wash, dim ambience",
  "فلاش قاسٍ للصدمة": "harsh cold white shock flash, high contrast",
  "دفء ذهبي للنصر": "warm golden triumph glow",
  "توتر رمادي بارد": "desaturated cold grey tension light",
};

function normalize(t: string): string {
  return t
    .replace(/[ـ]/g, "")
    .replace(/\r/g, "")
    .trim();
}

function splitSentences(narrative: string): string[] {
  const clean = normalize(narrative);
  if (!clean) return [];
  const parts = clean
    .split(/\n{2,}|(?<=[.!؟?…؛:])\s+|\n+/)
    .map((s) => s.trim())
    .filter((s) => s.length >= 12);
  return parts.slice(0, 42);
}

function chunkSentences(sentences: string[]): string[] {
  const size = sentences.length > 24 ? 3 : sentences.length > 10 ? 2 : 1;
  const chunks: string[] = [];
  for (let i = 0; i < sentences.length; i += size) {
    chunks.push(sentences.slice(i, i + size).join(" "));
  }
  const capped = chunks.slice(0, 18);
  if (chunks.length > 18) {
    capped[capped.length - 1] = `${capped[capped.length - 1]} ${chunks.slice(18).join(" ")}`;
  }
  return capped;
}

function detectEmotion(text: string) {
  for (const e of EMOTION_LEXICON) {
    if (e.words.some((w) => text.includes(w))) return e;
  }
  return EMOTION_LEXICON[EMOTION_LEXICON.length - 1]; // محايد
}

function detectRegion(text: string) {
  for (const r of REGIONS) {
    if (r.keys.some((k) => text.includes(k))) return r;
  }
  return null;
}

function cap(text: string, n: number): string {
  const t = text.trim();
  return t.length > n ? `${t.slice(0, n).trimEnd()}…` : t;
}

function makeTitle(chunk: string, isMap: boolean, region: { label: string } | null, emotion: { key: string }): string {
  const assassination = chunk.includes("اغتيا") || chunk.includes("اغتيل");
  if (assassination) return "لحظة الاغتيال";
  if (isMap && region) return `خريطة ${region.label} — ${emotion.key}`;
  const first = chunk.split(/\s+/).slice(0, 6).join(" ");
  return cap(first, 58);
}

export function runBreakdown(input: {
  narrative: string;
  notes: string;
  assets: EngineAsset[];
  styleLock: string;
  negative?: string;
}): EngineResult {
  const { assets, styleLock } = input;
  const notes = normalize(input.notes || "");
  const chars = assets.filter((a) => a.type === "CHAR");
  const maps = assets.filter((a) => a.type === "MAP");
  const bgs = assets.filter((a) => a.type === "BG");
  const props = assets.filter((a) => a.type === "PROP");
  const negative = input.negative || NEGATIVE_DEFAULT;

  const sentences = splitSentences(input.narrative);
  const chunks = chunkSentences(sentences.length ? sentences : [normalize(input.narrative || "مشهد افتتاحي")]);

  /* قواعد الملاحظات الإخراجية */
  const forceShockOnAssassination =
    /(صدمة|انفجار).*(اغتيال|اغتيل)|([ا]غتيال|اغتيل).*(صدمة|انفجار)/.test(notes);
  const shockedExpr = notes.includes("انفجار") && notes.includes("اغتيال") ? "انفجار" : "صدمة";
  const lastSceneCrying = notes.includes("بكاء") && (notes.includes("الأخير") || notes.includes("الختام") || notes.includes("انهيار"));
  const notesForceMaps = notes.includes("خريطة") || notes.includes("MAP");

  const scenes: EngineScene[] = [];
  const missingAll: MissingRef[] = [];

  chunks.forEach((chunk, idx) => {
    const n = idx + 1;
    const hay = `${chunk} ${notes}`;
    const missing: MissingRef[] = [];

    /* الشخصيات: مطابقة من المكتبة حصرًا */
    const matchedChars = chars.filter((c) => {
      const tokens = c.name
        .split(/\s+/)
        .filter((t) => t.length >= 3);
      const en = (c.nameEn || "").toLowerCase();
      return tokens.some((t) => chunk.includes(t)) || (en && chunk.toLowerCase().includes(en));
    });

    /* أسماء شهيرة بلا مصدر → نواقص */
    for (const f of FAMOUS_FIGURES) {
      const mentioned = f.keys.some((k) => chunk.includes(k));
      if (!mentioned) continue;
      const covered = matchedChars.some((c) => f.keys.some((k) => c.name.includes(k)) || matchedChars.some((m) => f.label.includes(m.name)));
      if (!covered) missing.push({ kind: "CHAR", label: f.label });
    }

    /* الخريطة */
    const region = detectRegion(hay);
    const wantsMap = !!region || (notesForceMaps && chunk.includes("حرب")) || /خريطة|حدود|دول|جبهات/.test(chunk);
    let mapId: string | null = null;
    if (wantsMap) {
      const exact = region ? maps.find((m) => m.name.includes(region.label)) ?? maps.find((m) => (m.era || "") && chunk.includes(m.era!)) : null;
      if (exact) mapId = exact.id;
      else if (region) missing.push({ kind: "MAP", label: `MAP — ${region.label} (أنشئها في أطلس الخرائط)` });
      else if (maps.length) mapId = maps[0].id;
    }

    /* موقع التصوير */
    let bgId: string | null = null;
    let locationText: string | null = null;
    for (const h of BG_HINTS) {
      if (h.keys.some((k) => chunk.includes(k))) {
        const hit = bgs.find((b) => h.bucket.some((bk) => b.name.includes(bk)));
        if (hit) {
          bgId = hit.id;
          locationText = hit.name;
        }
        break;
      }
    }
    if (!locationText && region) locationText = region.label;

    /* العناصر المتكررة */
    const matchedProps = props.filter((p) =>
      p.name.split(/\s+/).filter((t) => t.length >= 3).some((t) => chunk.includes(t))
    );
    if (/نفط|بترول/.test(chunk) && !matchedProps.some((p) => p.name.includes("نفط") || p.name.includes("برميل"))) {
      missing.push({ kind: "PROP", label: "برميل نفط" });
    }

    /* الانفعال */
    let emo = detectEmotion(chunk);
    if (forceShockOnAssassination && /اغتيا|اغتيل/.test(chunk)) {
      emo = EMOTION_LEXICON.find((e) => e.key === shockedExpr)!;
    }
    if (lastSceneCrying && n === chunks.length) {
      emo = EMOTION_LEXICON.find((e) => e.key === "بكاء")!;
    }
    if (wantsMap && !matchedChars.length) {
      emo = { ...emo, camera: "لقطة واسعة — زاوية جوية", lighting: emo.key === "محايد" ? "تيل محايد سينمائي" : emo.lighting };
    }

    /* البرومبت EN */
    const refLines: string[] = [];
    for (const c of matchedChars) refLines.push(`attach exact reference: “${displayName(c as never as Parameters<typeof displayName>[0])}”`);
    if (mapId) {
      const m = maps.find((x) => x.id === mapId)!;
      refLines.push(`attach base map (do NOT redraw borders): “${displayName(m as never as Parameters<typeof displayName>[0])}”`);
    }
    if (bgId) {
      const b = bgs.find((x) => x.id === bgId)!;
      refLines.push(`attach location plate: “${displayName(b as never as Parameters<typeof displayName>[0])}”`);
    }
    for (const p of matchedProps) refLines.push(`attach prop reference: “${displayName(p as never as Parameters<typeof displayName>[0])}”`);

    const charsEn = matchedChars.map((c) => c.nameEn || c.name);
    const cameraEn = CAMERA_EN[emo.camera] ?? "medium shot";
    const lightEn = LIGHT_EN[emo.lighting] ?? "cinematic light";

    const sceneEn = [
      `${cameraEn} — ${charsEn.length ? charsEn.join(" and ") : "the scene"}${
        locationText ? ` at ${locationText}` : ""
      }, ${emo.beatEn}.`,
      wantsMap && mapId
        ? `Keep the map geography pixel-identical to the attached base map — only add arrows, flags and explosion markers.`
        : `Keep faces, hair, outfits and props pixel-identical to the attached references.`,
      wantsMap && !mapId ? `Map style follows MAP-STYLE reference only (no invented borders).` : "",
      `${lightEn}.`,
      `Narrative beat (AR): «${cap(chunk, 140)}»`,
    ]
      .filter(Boolean)
      .join(" ");

    const exprEn = matchedChars.length
      ? matchedChars
          .map(
            (c) =>
              `${c.nameEn || c.name}: ${emo.en} — only eyes, eyebrows and mouth change; face geometry, hair and outfit stay pixel-identical to the reference.`
          )
          .join("\n")
      : `no characters — map/scenery shot; geometry and colors identical to the attached map reference.`;

    scenes.push({
      num: n,
      title: makeTitle(chunk, wantsMap, region, emo),
      narration: cap(chunk, 240),
      expression: emo.key,
      expressionEn: emo.en,
      camera: emo.camera,
      lighting: emo.lighting,
      locationText,
      promptRef: refLines.join("\n"),
      promptScene: sceneEn,
      promptExpression: exprEn,
      promptStyle: styleLock,
      promptNegative: negative,
      characterIds: matchedChars.map((c) => c.id),
      mapId,
      bgId,
      propIds: matchedProps.map((p) => p.id),
      missing,
      isMap: wantsMap,
    });

    for (const m of missing) {
      if (!missingAll.some((x) => x.kind === m.kind && x.label === m.label)) missingAll.push(m);
    }
  });

  return {
    scenes,
    missing: missingAll,
    summary: `${scenes.length} مشهد — ${scenes.reduce((a, s) => a + s.characterIds.length, 0)} استدعاء شخصية — ${scenes.filter((s) => s.isMap).length} مشاهد خريطة — ${missingAll.length} نواقص`,
  };
}
