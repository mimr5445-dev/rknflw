import type { Asset, Scene } from "@/db/schema";
import { NEGATIVE_DEFAULT } from "@/lib/consts";

export { NEGATIVE_DEFAULT };

/* ─────────────────────────────────────────────────────────────
   استوديو الهوية الثابتة — الثوابت المرجعية المستمدة من الخطة
   كل شيء هنا يعكس "بروتوكول التسمية" و"دستور الاستوديو"
   ───────────────────────────────────────────────────────────── */

export type SourceTypeKey =
  | "RULE"
  | "STYLE"
  | "CHAR"
  | "CHAR-EXP"
  | "MAP"
  | "MAP-STYLE"
  | "BG"
  | "PROP";

export const SOURCE_TYPES: {
  key: SourceTypeKey;
  label: string;
  hint: string;
  color: string;
}[] = [
  { key: "RULE", label: "دستور العمل", hint: "تعليمات إلزامية — يُرفع أولاً ولا يتغير", color: "#F4504E" },
  { key: "STYLE", label: "دليل الفن", hint: "سطر النمط المقدس + جدول الوجه المطاطي", color: "#E9B44C" },
  { key: "CHAR", label: "شخصية", hint: "الصورة المرجعية = بطاقة الهوية الرسمية الوحيدة", color: "#8B5CF6" },
  { key: "CHAR-EXP", label: "ورقة تعابير", hint: "شبكة التعابير الستة المعتمدة للشخصية", color: "#C084FC" },
  { key: "MAP", label: "خريطة", hint: "حقيقة جغرافية — تُعدَّل ولا تُولَّد", color: "#2DD4BF" },
  { key: "MAP-STYLE", label: "نمط الخرائط", hint: "عين اللون والخط والإضاءة لأي خريطة", color: "#22D3EE" },
  { key: "BG", label: "موقع تصوير", hint: "المسرح الثابت عبر كل الحلقات", color: "#60A5FA" },
  { key: "PROP", label: "عنصر متكرر", hint: "توقيع بصري يعرفه المتابعون", color: "#FB923C" },
];

export const TYPE_MAP = Object.fromEntries(SOURCE_TYPES.map((t) => [t.key, t])) as Record<
  SourceTypeKey,
  (typeof SOURCE_TYPES)[number]
>;

export function typeColor(type: string): string {
  return (TYPE_MAP as Record<string, { color: string }>)[type]?.color ?? "#9A9AA8";
}
export function typeLabel(type: string): string {
  return (TYPE_MAP as Record<string, { label: string }>)[type]?.label ?? type;
}

/** اسم المصدر بصيغة NotebookLM الرسمية: CHAR — الاسم — الوظيفة */
export function displayName(a: Pick<Asset, "type" | "name" | "role" | "era">): string {
  const tail = a.type === "MAP" ? a.era : a.role;
  return `${a.type} — ${a.name}${tail ? ` — ${tail}` : ""}`;
}

/* ─── التعابير المطاطية (جدول STYLE) ─── */
export const EXPRESSIONS: { ar: string; en: string; hint: string }[] = [
  { ar: "محايد", en: "neutral, composed face", hint: "خط الأساس" },
  { ar: "انزعاج", en: "mildly annoyed, furrowed brows, tight mouth", hint: "توتر متصاعد" },
  { ar: "غضب", en: "angry, thick furrowed brows, open shouting mouth", hint: "غضب مكبوت" },
  { ar: "انفجار", en: "explosive rage, wide eyes, screaming mouth, stretched rubber face", hint: "ذروة درامية" },
  { ar: "فرح", en: "wide joyful smile, bright sparkling eyes", hint: "انتصار/ارتياح" },
  { ar: "بكاء", en: "crying hard, trembling mouth, big tears", hint: "انهيار" },
  { ar: "صدمة", en: "shocked, wide oval eyes, dropped jaw", hint: "الخبر الصادم" },
  { ar: "سخرية", en: "sarcastic smirk, one raised brow, half-closed eyes", hint: "تهكم سياسي" },
];

/* ─── الكادرات ─── */
export const CAMERAS: { ar: string; en: string }[] = [
  { ar: "لقطة متوسطة — مستوى النظر", en: "medium shot, eye-level angle" },
  { ar: "لقطة قريبة — زاوية منخفضة", en: "tight close-up, low heroic angle" },
  { ar: "لقطة قريبة بطيئة", en: "slow push-in close-up, eye-level" },
  { ar: "لقطة واسعة — زاوية جوية", en: "wide establishing shot, high aerial angle" },
  { ar: "لقطة واسعة — مستوى الأرض", en: "wide shot, ground-level angle" },
  { ar: "كتف إلى كتف — مواجهة", en: "over-the-shoulder confrontation framing" },
];

/* ─── الإضاءة المزاجية ─── */
export const LIGHTINGS: { ar: string; en: string }[] = [
  { ar: "تيل محايد سينمائي", en: "cinematic neutral teal grade, soft key light" },
  { ar: "غسل أحمر للغضب", en: "heavy red anger wash flooding the frame" },
  { ar: "أزرق بارد للحزن", en: "cold blue sorrow wash, dim ambience" },
  { ar: "فلاش قاسٍ للصدمة", en: "harsh cold white shock flash, high contrast" },
  { ar: "دفء ذهبي للنصر", en: "warm golden triumph glow" },
  { ar: "توتر رمادي بارد", en: "desaturated cold grey tension light" },
];

/* ─── حالات المشهد والحلقة ─── */
export const SCENE_STATUSES: { key: string; label: string; color: string }[] = [
  { key: "draft", label: "مسودة", color: "#9A9AA8" },
  { key: "ready", label: "جاهز للتوليد", color: "#E9B44C" },
  { key: "generated", label: "وُلّدت", color: "#2DD4BF" },
  { key: "approved", label: "معتمدة", color: "#4ADE80" },
];
export const sceneStatusMeta = (s: string) =>
  SCENE_STATUSES.find((x) => x.key === s) ?? SCENE_STATUSES[0];

export const EPISODE_STATUSES: { key: string; label: string; color: string }[] = [
  { key: "prep", label: "تحضير", color: "#9A9AA8" },
  { key: "production", label: "إنتاج", color: "#E9B44C" },
  { key: "edit", label: "مونتاج", color: "#60A5FA" },
  { key: "published", label: "منشور", color: "#4ADE80" },
];
export const episodeStatusMeta = (s: string) =>
  EPISODE_STATUSES.find((x) => x.key === s) ?? EPISODE_STATUSES[0];

/* ─── بوابات الجودة الأربع (من قائمة المراجعة في الخطة) ─── */
export const GATES: { key: string; title: string; desc: string }[] = [
  { key: "chars", title: "بوابة الشخصيات", desc: "كل اسم في السرد له استشهاد بمصدر CHAR — بلا اختراع وبلا استعارة وجوه" },
  { key: "ref", title: "بوابة المرجع", desc: "حقل [REF] حاضر في كل برومبت بلا استثناء" },
  { key: "styleLock", title: "بوابة النمط", desc: "[STYLE LOCK] مكرر حرفيًا كلمة بكلمة في كل برومبت" },
  { key: "maps", title: "بوابة الجغرافيا", desc: "كل مشهد خريطة يستخدم مصدر MAP المعتمد — لا حدود مخترعة" },
];

/* ─── تجميع البرومبت النهائي بصيغة الخطة ─── */
export function assemblePrompt(s: Pick<
  Scene,
  "promptRef" | "promptScene" | "promptExpression" | "promptStyle" | "promptNegative"
>): string {
  return [
    s.promptRef ? `[REF]: ${s.promptRef}` : "[REF]: ⚠ لا يوجد مرجع — ممنوع التوليد قبل إرفاق الصورة",
    `[SCENE]: ${s.promptScene}`,
    `[EXPRESSION]: ${s.promptExpression}`,
    `[STYLE LOCK]: ${s.promptStyle}`,
    `[NEGATIVE]: ${s.promptNegative || NEGATIVE_DEFAULT}`,
  ].join("\n");
}

/** سلسلة أمان لأسماء الملفات داخل ملف ZIP */
export function slug(input: string, fallback = "file"): string {
  const s = (input || "")
    .normalize("NFKD")
    .replace(/[^\w\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 60);
  return s || fallback;
}

export function pad2(n: number): string {
  return String(n).padStart(2, "0");
}
